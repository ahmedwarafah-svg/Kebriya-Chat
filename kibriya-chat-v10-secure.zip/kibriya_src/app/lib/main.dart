import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'core/providers.dart';
import 'screens/login.dart';
import 'screens/home.dart';
import 'screens/room.dart';
import 'screens/profile.dart';
import 'screens/messages.dart';
import 'screens/discover.dart';
import 'screens/activities.dart';
import 'screens/referrals.dart';
import 'screens/tasks.dart';
import 'screens/rating.dart';
import 'screens/admin.dart';
import 'screens/gift_center.dart';
import 'screens/games.dart';
import 'screens/create_room.dart';
import 'screens/membership.dart';
import 'screens/wealth.dart';
import 'screens/cinema.dart';
import 'screens/social.dart';
import 'core/config.dart';

void main(){ WidgetsFlutterBinding.ensureInitialized(); runApp(const ProviderScope(child:KibriyaApp())); }
class KibriyaApp extends ConsumerStatefulWidget{const KibriyaApp({super.key});@override ConsumerState<KibriyaApp> createState()=>_KibriyaAppState();}
class _KibriyaAppState extends ConsumerState<KibriyaApp>{
  late final GoRouter router;
  @override void initState(){super.initState(); ref.read(authProvider.notifier).restore(); router=GoRouter(initialLocation:'/home',redirect:(c,s){final logged=ref.read(authProvider).valueOrNull!=null; final login=s.matchedLocation=='/login'; if(!logged&&!login)return '/login'; if(logged&&login)return '/home'; return null;},routes:[GoRoute(path:'/login',builder:(_,__)=>const LoginScreen()),ShellRoute(builder:(c,s,child)=>Scaffold(body:child,bottomNavigationBar:const MainNav()),routes:[GoRoute(path:'/home',builder:(_,__)=>const HomeScreen()),GoRoute(path:'/discover',builder:(_,__)=>const DiscoverScreen()),GoRoute(path:'/create',builder:(_,__)=>const CreateRoomScreen()),GoRoute(path:'/messages',builder:(_,__)=>const MessagesScreen()),GoRoute(path:'/profile',builder:(_,__)=>const ProfileScreen())]),GoRoute(path:'/room/:id',builder:(c,s)=>RoomScreen(roomId:s.pathParameters['id']!)),GoRoute(path:'/activities',builder:(_,__)=>const ActivitiesScreen()),GoRoute(path:'/referrals',builder:(_,__)=>const ReferralsScreen()),GoRoute(path:'/tasks',builder:(_,__)=>const TasksScreen()),GoRoute(path:'/rating',builder:(_,__)=>const RatingScreen()),GoRoute(path:'/admin',builder:(_,__)=>const AdminScreen()),GoRoute(path:'/gifts',builder:(_,__)=>const GiftCenterScreen()),GoRoute(path:'/games',builder:(_,__)=>const GamesScreen()),GoRoute(path:'/membership',builder:(_,__)=>const MembershipScreen()),GoRoute(path:'/wealth',builder:(_,__)=>const WealthScreen()),GoRoute(path:'/cinema/:roomId',builder:(c,s)=>CinemaScreen(roomId:s.pathParameters['roomId']!)),GoRoute(path:'/chat/:userId',builder:(c,s)=>DirectChatScreen(userId:s.pathParameters['userId']!)),GoRoute(path:'/families',builder:(_,__)=>const FamiliesScreen()),GoRoute(path:'/family-chat/:id',builder:(c,s)=>FamilyChatScreen(familyId:s.pathParameters['id']!))]);}
  @override Widget build(BuildContext context)=>MaterialApp.router(title:AppConfig.brand,debugShowCheckedModeBanner:false,theme:ThemeData(useMaterial3:true,fontFamily:'Arial',brightness:Brightness.dark,scaffoldBackgroundColor:const Color(0xFF07111F),colorSchemeSeed:const Color(0xFFD7A84A)),routerConfig:router);
}
class MainNav extends StatelessWidget{const MainNav({super.key});@override Widget build(BuildContext c){final loc=GoRouterState.of(c).uri.path; int i=loc=='/home'?0:loc=='/discover'?1:loc=='/create'?2:loc=='/messages'?3:4; return NavigationBar(selectedIndex:i,onDestinationSelected:(x){const p=['/home','/discover','/create','/messages','/profile'];context.go(p[x]);},destinations:const[NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.explore_outlined),label:'اكتشف'),NavigationDestination(icon:Icon(Icons.add_circle_outline),label:'إنشاء'),NavigationDestination(icon:Icon(Icons.chat_bubble_outline),label:'الرسائل'),NavigationDestination(icon:Icon(Icons.person_outline),label:'أنا')]);}}
