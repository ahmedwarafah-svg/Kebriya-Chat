import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';
import '../services/api.dart';
final apiProvider=Provider<Api>((ref)=>Api());
final authProvider=StateNotifierProvider<AuthController,AsyncValue<UserModel?>>((ref)=>AuthController(ref.read(apiProvider)));
class AuthController extends StateNotifier<AsyncValue<UserModel?>>{
  final Api api; AuthController(this.api):super(const AsyncData(null));
  Future<bool> login(String u,String p) async { state=const AsyncLoading(); try { final x=await api.login(u,p); final sp=await SharedPreferences.getInstance(); await sp.setString('token',x.$2); state=AsyncData(x.$1); return true; } catch(e){ state=AsyncError(e,StackTrace.current); return false; } }
  Future<bool> register(String u,String n,String p,{String? referralCode}) async { state=const AsyncLoading(); try { final x=await api.register(u,n,p,referralCode:referralCode); final sp=await SharedPreferences.getInstance(); await sp.setString('token',x.$2); state=AsyncData(x.$1); return true; } catch(e){ state=AsyncError(e,StackTrace.current); return false; } }
  Future<void> restore() async { final sp=await SharedPreferences.getInstance(); if(sp.getString('token')==null)return; try{state=AsyncData(await api.me());}catch(_){await sp.remove('token');state=const AsyncData(null);} }

  Future<bool> googleLogin(String idToken) async { state=const AsyncLoading(); try { final x=await api.googleLogin(idToken); final sp=await SharedPreferences.getInstance(); await sp.setString('token',x.$2); state=AsyncData(x.$1); return true; } catch(e){ state=AsyncError(e,StackTrace.current); return false; } }
  Future<bool> phoneLogin(String phone,String otp) async { state=const AsyncLoading(); try { final x=await api.verifyPhoneOtp(phone,otp); final sp=await SharedPreferences.getInstance(); await sp.setString('token',x.$2); state=AsyncData(x.$1); return true; } catch(e){ state=AsyncError(e,StackTrace.current); return false; } }
  Future<void> logout() async { final sp=await SharedPreferences.getInstance(); await sp.remove('token'); state=const AsyncData(null); }
}
