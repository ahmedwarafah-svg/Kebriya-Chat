import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:zego_uikit_prebuilt_live_audio_room/zego_uikit_prebuilt_live_audio_room.dart';
import '../core/providers.dart';
import '../core/config.dart';
import 'room_tools.dart';

class RoomScreen extends ConsumerStatefulWidget {
  final String roomId;
  const RoomScreen({super.key, required this.roomId});
  @override ConsumerState<RoomScreen> createState() => _RoomState();
}

class _RoomState extends ConsumerState<RoomScreen> {
  Map<String,dynamic>? token, details;
  List<dynamic> gifts=[];
  Map<String,dynamic> bagItems={};
  List<dynamic> recipients=[];
  bool loading=true;
  String? error;
  int sentCoins=0, giftCount=0, currentCoins=0, lastDelta=0;
  String category='all';
  String? selectedReceiverId;
  dynamic burstGift;
  int burstTotal=0, burstIndex=0;
  Timer? burstTimer;
  IO.Socket? socket;
  List<Map<String,dynamic>> emoteOverlays=[];
  int roomCoins=0, roomGifts=0, roomAttraction=0;
  bool rocketsActive=false;


  @override void initState(){super.initState();_prepare();}
  Future<void> _prepare() async {
    try {
      final a=ref.read(apiProvider);
      await a.joinRoom(widget.roomId);
      final r=await Future.wait([a.zegoToken(widget.roomId),a.roomDetails(widget.roomId),a.giftCatalog(),a.bag(),a.wallet(),a.giftRecipients(widget.roomId),a.dio.get('/api/room/${widget.roomId}/stats')]);
      if(mounted){
        final b=Map<String,dynamic>.from(r[3] as Map);
        for(final item in List<dynamic>.from(b['items']??[])){bagItems['${item['gift_id']}']=item['quantity'];}
        final w=Map<String,dynamic>.from(r[4] as Map);
        setState((){
          token=r[0] as Map<String,dynamic>;
          details=r[1] as Map<String,dynamic>;
          gifts=r[2] as List<dynamic>;
          currentCoins=int.tryParse('${w['wallet']?['coins']??0}')??0;
          recipients=List<dynamic>.from(r[5] as List<dynamic>);
          final st=Map<String,dynamic>.from(r[6].data as Map);
          roomCoins=int.tryParse('${st['total_coins']??0}')??0; roomGifts=int.tryParse('${st['total_gifts']??0}')??0; roomAttraction=int.tryParse('${st['total_attraction']??0}')??0;
        });
        _connectRoomSocket();
      }
    } catch(e){if(mounted)setState(()=>error='$e');}
    finally{if(mounted)setState(()=>loading=false);}
  }
  void _connectRoomSocket() async { final sp=await SharedPreferences.getInstance(); final jwt=sp.getString('token'); if(jwt==null)return; socket=IO.io(AppConfig.apiBaseUrl,IO.OptionBuilder().setTransports(['websocket']).setAuth({'token':jwt}).disableAutoConnect().build()); socket!.connect(); socket!.on('room:emote',(data){if(!mounted)return; final m=Map<String,dynamic>.from(data as Map); setState(()=>emoteOverlays=[...emoteOverlays,{'userId':'${m['userId']}','code':'${m['emote']?['code']??'heart'}'}]); Future.delayed(const Duration(milliseconds:1800),(){if(mounted&&emoteOverlays.isNotEmpty)setState(()=>emoteOverlays=List<Map<String,dynamic>>.from(emoteOverlays)..removeAt(0));});}); socket!.on('room:rockets',(data){if(!mounted)return;setState(()=>rocketsActive=true);_snack('🚀 انطلقت 3 صواريخ! تم الوصول لهدف دعم الغرفة');Future.delayed(const Duration(seconds:3),(){if(mounted)setState(()=>rocketsActive=false);});}); }
  @override void dispose(){burstTimer?.cancel();socket?.dispose();super.dispose();}

  Future<void> _send(dynamic g) async {
    if(recipients.isEmpty){_snack('لا يوجد مستلم آخر في الغرفة الآن');return;}
    final picked=await _openGiftSheet(g);
    if(picked==null)return;
    final receiverId='${picked['receiverId']}';
    final quantity=picked['quantity'] as int;
    try{
      final r=await ref.read(apiProvider).dio.post('/api/gifts/send',data:{'roomId':widget.roomId,'receiverId':receiverId,'giftId':'${g['id']}','quantity':quantity});
      final d=Map<String,dynamic>.from(r.data);
      final before=int.tryParse('${d['senderCoinsBefore']}')??currentCoins;
      final after=int.tryParse('${d['senderCoinsAfter']}')??(currentCoins-(int.tryParse('${d['totalCoins']}')??0));
      if(mounted)setState((){
        currentCoins=after;
        sentCoins+=int.tryParse('${d['totalCoins']}')??0;
        giftCount+=quantity;
        roomGifts+=quantity; roomCoins+=int.tryParse('${d['totalCoins']}')??0; roomAttraction+=int.tryParse('${d['totalCoins']}')??0;
        lastDelta=after-before;
      });
      _showBurst(g,quantity);
      _snack('تم إرسال ${g['name']} ×$quantity إلى ${picked['name']}  • رصيدك الآن $after Coins');
    }catch(e){_snack('تعذر إرسال الهدية: $e');}
  }

  Future<Map<String,dynamic>?> _openGiftSheet(dynamic g) async {
    int q=1;
    final maxCombo=(int.tryParse('${g['combo_max']}')??100).clamp(1,100);
    String? receiver=selectedReceiverId ?? (recipients.isNotEmpty?'${recipients.first['user_id']}':null);
    return showModalBottomSheet<Map<String,dynamic>>(
      context:context,isScrollControlled:true,backgroundColor:const Color(0xFF17121B),
      builder:(ctx)=>StatefulBuilder(builder:(ctx,setSheet)=>Padding(
        padding:EdgeInsets.only(left:16,right:16,top:16,bottom:MediaQuery.of(ctx).viewInsets.bottom+18),
        child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[Text('${g['metadata']?['icon']??'🎁'}',style:const TextStyle(fontSize:42)),const SizedBox(width:10),Expanded(child:Text('${g['name']}',style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900))),Text('🪙 ${g['price_coins']} / 1')]),
          const SizedBox(height:14),
          const Text('إرسال إلى',style:TextStyle(fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          SizedBox(height:70,child:ListView(scrollDirection:Axis.horizontal,children:recipients.map((u)=>GestureDetector(onTap:()=>setSheet(()=>receiver='${u['user_id']}'),child:Container(width:100,margin:const EdgeInsets.only(right:8),padding:const EdgeInsets.all(8),decoration:BoxDecoration(borderRadius:BorderRadius.circular(14),border:Border.all(color:receiver=='${u['user_id']}'?Colors.amber:Colors.white12)),child:Column(children:[CircleAvatar(radius:15,child:Text((('${u['display_name']??'?'}').trim().isEmpty ? '?' : '${u['display_name']}')[0])),Text('${u['display_name']??''}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11))])))).toList())),
          const SizedBox(height:14),
          Row(children:[const Text('العدد',style:TextStyle(fontWeight:FontWeight.bold)),const Spacer(),IconButton(onPressed:q>1?()=>setSheet(()=>q--):null,icon:const Icon(Icons.remove_circle_outline)),Text('$q',style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),IconButton(onPressed:q<maxCombo?()=>setSheet(()=>q++):null,icon:const Icon(Icons.add_circle_outline))]),
          Wrap(spacing:6,children:[1,5,10,20,50,99,100].where((x)=>x<=maxCombo).map((x)=>ActionChip(label:Text('×$x'),onPressed:()=>setSheet(()=>q=x))).toList()),
          const SizedBox(height:12),
          Container(width:double.infinity,padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.white.withOpacity(.06),borderRadius:BorderRadius.circular(14)),child:Text('الإجمالي: 🪙 ${int.tryParse('${g['price_coins']}')!*q}  •  الحد الأقصى: ×$maxCombo',style:const TextStyle(fontWeight:FontWeight.bold))),
          const SizedBox(height:12),
          SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:receiver==null?null:()=>Navigator.pop(ctx,{'receiverId':receiver,'quantity':q,'name':recipients.firstWhere((x)=>'${x['user_id']}'==receiver)['display_name']}),icon:const Icon(Icons.card_giftcard),label:Text('إرسال ×$q')))
        ])))
    );
  }

  void _showBurst(dynamic g,int quantity){
    burstTimer?.cancel();
    setState((){burstGift=g;burstTotal=quantity;burstIndex=0;});
    burstTimer=Timer.periodic(const Duration(milliseconds:140),(t){
      if(!mounted){t.cancel();return;}
      if(burstIndex>=burstTotal-1){t.cancel();Future.delayed(const Duration(milliseconds:450),(){if(mounted)setState(()=>burstGift=null);});return;}
      setState(()=>burstIndex++);
    });
  }
  void _snack(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s),duration:const Duration(seconds:2)));}

  @override Widget build(BuildContext c){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    if(error!=null)return Scaffold(appBar:AppBar(title:const Text('كبرياء شات')),body:Center(child:Text('تعذر الدخول\n$error')));
    final t=token!;
    final base=t['isHost']==true?ZegoUIKitPrebuiltLiveAudioRoomConfig.host():ZegoUIKitPrebuiltLiveAudioRoomConfig.audience();
    base.seat.layout.rowConfigs=[ZegoLiveAudioRoomLayoutRowConfig(count:2,alignment:ZegoLiveAudioRoomLayoutAlignment.center),for(int i=0;i<7;i++)ZegoLiveAudioRoomLayoutRowConfig(count:4,alignment:ZegoLiveAudioRoomLayoutAlignment.spaceAround)];
    base.seat.hostIndexes=[0];base.seat.showSoundWaveInAudioMode=true;if(t['isHost']==true)base.seat.takeIndexWhenJoining=0;
    final filtered=gifts.where((g)=>category=='all'||g['category']==category).take(10).toList();
    return Scaffold(body:Stack(children:[
      ZegoUIKitPrebuiltLiveAudioRoom(appID:(t['appId'] as num).toInt(),userID:'${t['userId']}',userName:'${t['userName']}',roomID:widget.roomId,token:'${t['token']}',config:base,events:ZegoUIKitPrebuiltLiveAudioRoomEvents(room:ZegoLiveAudioRoomRoomEvents(onStateChanged:(s){if(s.reason==ZegoRoomStateChangedReason.Logout&&mounted)Navigator.pop(context);}),)),
      Positioned(left:10,right:10,top:48,child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[_tool(Icons.emoji_emotions,'إيموشن',()=>showEmotes(context,widget.roomId)),_tool(Icons.tune,'إعدادات',()=>showRoomTools(context,widget.roomId)),_tool(Icons.sports_esports,'PK',()=>_snack('من أدوات الغرفة يمكنك بدء تحدي PK'))])),
      Positioned(left:10,right:10,bottom:12,child:_giftPanel(filtered)),
      if(burstGift!=null)Positioned.fill(child:IgnorePointer(child:Center(child:AnimatedScale(scale:1.0+(burstIndex%3)*.08,duration:const Duration(milliseconds:90),child:Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(color:Colors.black.withOpacity(.55),borderRadius:BorderRadius.circular(28)),child:Column(mainAxisSize:MainAxisSize.min,children:[Text('${burstGift['metadata']?['icon']??'🎁'}',style:const TextStyle(fontSize:82)),Text('×${burstIndex+1}',style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900,color:Colors.amber)),Text('تم الإرسال',style:const TextStyle(fontSize:12))]))))),
      if(rocketsActive)Positioned.fill(child:IgnorePointer(child:Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[for(int i=0;i<3;i++)TweenAnimationBuilder<double>(tween:Tween(begin:1,end:1.45),duration:Duration(milliseconds:650+i*120),builder:(c,v,ch)=>Transform.scale(scale:v,child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Text('🚀',style:TextStyle(fontSize:64)),const Text('💥',style:TextStyle(fontSize:36))])))]))),
      ...emoteOverlays.asMap().entries.map((e)=>Positioned(left:30+(e.key%3)*110,top:170+(e.key%2)*90,child:IgnorePointer(child:TweenAnimationBuilder<double>(tween:Tween(begin:.4,end:1),duration:const Duration(milliseconds:500),builder:(c,v,ch)=>Transform.scale(scale:v,child:Text(_emoteEmoji(e.value['code']),style:const TextStyle(fontSize:54)))))))
    ]));
  }

  Widget _giftPanel(List<dynamic> gs)=>SafeArea(child:Container(padding:const EdgeInsets.all(9),decoration:BoxDecoration(color:Colors.black.withOpacity(.86),borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.amber.withOpacity(.35))),child:Column(mainAxisSize:MainAxisSize.min,children:[
    Row(children:[Text('🏆 روم ${roomCoins} 🪙  •  🎁 $roomGifts  •  ✨ $roomAttraction',style:const TextStyle(fontSize:9,fontWeight:FontWeight.bold)),const Spacer(),const Text('🎁 الهدايا',style:TextStyle(fontWeight:FontWeight.w900)),const SizedBox(width:8),_counter('🎁','$giftCount'),const SizedBox(width:5),_counter('🪙','$currentCoins'),const SizedBox(width:5),_counter('Δ','${lastDelta>=0?'+':''}$lastDelta'),IconButton(onPressed:()=>context.push('/cinema/${widget.roomId}'),icon:const Icon(Icons.ondemand_video)),const Spacer(),Text('المُرسل ×1–100',style:TextStyle(fontSize:10,color:Colors.white70))]),
    const SizedBox(height:5),
    Row(children:[_tiny('رصيدي','🪙 $currentCoins'),_tiny('أرسل','🪙 $sentCoins'),const Spacer(),Text('اللوحة ثابتة',style:TextStyle(fontSize:9,color:Colors.white54))]),
    SizedBox(height:38,child:ListView(scrollDirection:Axis.horizontal,children:[for(final x in ['all','basic','combo','luck','svip','cp','celebrity','country'])Padding(padding:const EdgeInsets.symmetric(horizontal:3),child:ChoiceChip(label:Text(_cat(x),style:const TextStyle(fontSize:10)),selected:category==x,onSelected:(_)=>setState(()=>category=x)))])),
    SizedBox(height:82,child:ListView(scrollDirection:Axis.horizontal,children:gs.map((g)=>GestureDetector(onTap:()=>_send(g),child:Container(width:78,margin:const EdgeInsets.symmetric(horizontal:3),padding:const EdgeInsets.all(5),decoration:BoxDecoration(color:Colors.white.withOpacity(.06),borderRadius:BorderRadius.circular(14)),child:Column(children:[Expanded(child:Text('${g['metadata']?['icon']??'🎁'}',style:const TextStyle(fontSize:30))),Text('${g['name']}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:9)),Text('🪙${g['price_coins']}  ×${g['combo_max']}',style:const TextStyle(fontSize:9))])))).toList()))
  ]));
  Widget _counter(String a,String b)=>Container(padding:const EdgeInsets.symmetric(horizontal:7,vertical:3),decoration:BoxDecoration(color:Colors.white.withOpacity(.07),borderRadius:BorderRadius.circular(10)),child:Text('$a $b',style:const TextStyle(fontSize:10,fontWeight:FontWeight.bold)));
  Widget _tiny(String a,String b)=>Container(margin:const EdgeInsets.only(right:5),padding:const EdgeInsets.symmetric(horizontal:7,vertical:2),decoration:BoxDecoration(color:Colors.white.withOpacity(.05),borderRadius:BorderRadius.circular(8)),child:Text('$a $b',style:const TextStyle(fontSize:9)));
  Widget _tool(IconData i,String t,VoidCallback f)=>Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:FilledButton.tonalIcon(onPressed:f,icon:Icon(i,size:18),label:Text(t,style:const TextStyle(fontSize:11))));
  String _emoteEmoji(String c)=>{'heart':'❤️','fire':'🔥','crown':'👑','star':'⭐','dragon':'🐉','galaxy':'🌌','royal':'🏆'}[c]??'✨';
  String _cat(String x)=>{'all':'الكل','basic':'أساسي','combo':'كومبو','luck':'حظ','svip':'SVIP','cp':'CP','celebrity':'مشاهير','country':'دول'}[x]??x;
}
