import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../core/providers.dart';
import '../core/config.dart';

class LoginScreen extends ConsumerStatefulWidget{const LoginScreen({super.key});@override ConsumerState<LoginScreen> createState()=>_LoginState();}
class _LoginState extends ConsumerState<LoginScreen>{
  final u=TextEditingController(),p=TextEditingController(),n=TextEditingController(),r=TextEditingController(),phone=TextEditingController(),otp=TextEditingController();
  bool register=false,busy=false,phoneMode=false,otpSent=false;
  Future<void> submit() async{if(u.text.trim().isEmpty||p.text.isEmpty||(register&&n.text.trim().isEmpty))return;setState(()=>busy=true);final ok=register?await ref.read(authProvider.notifier).register(u.text.trim(),n.text.trim(),p.text,referralCode:r.text.trim().isEmpty?null:r.text.trim()):await ref.read(authProvider.notifier).login(u.text.trim(),p.text);setState(()=>busy=false);if(!ok&&mounted){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تنفيذ العملية: ${ref.read(authProvider).error}')));}if(ok&&mounted)context.go('/home');}
  Future<void> requestOtp() async{try{await ref.read(apiProvider).requestPhoneOtp(phone.text.trim());setState(()=>otpSent=true);if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم طلب رمز التحقق')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر إرسال الرمز: $e')));}}
  Future<void> verifyOtp() async{setState(()=>busy=true);final ok=await ref.read(authProvider.notifier).phoneLogin(phone.text.trim(),otp.text.trim());setState(()=>busy=false);if(ok&&mounted)context.go('/home');else if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر التحقق: ${ref.read(authProvider).error}')));}
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:430),child:Column(children:[
    ClipRRect(borderRadius:BorderRadius.circular(28),child:Image.asset('assets/branding/logo.jpg',height:150,width:280,fit:BoxFit.cover)),const SizedBox(height:18),Text(AppConfig.brand,style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),Text(AppConfig.subtitle,style:TextStyle(color:Colors.white.withOpacity(.65))),const SizedBox(height:24),
    SegmentedButton<bool>(segments:const[ButtonSegment(value:false,label:Text('حساب عادي')),ButtonSegment(value:true,label:Text('رقم واتساب'))],selected:{phoneMode},onSelectionChanged:(v)=>setState(()=>phoneMode=v.first)),const SizedBox(height:18),
    if(phoneMode)...[
      TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'رقم واتساب',prefixIcon:Icon(Icons.phone))),const SizedBox(height:12),
      if(otpSent)TextField(controller:otp,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'رمز التحقق OTP',prefixIcon:Icon(Icons.verified))),const SizedBox(height:12),
      SizedBox(width:double.infinity,height:50,child:FilledButton(onPressed:busy?null:(otpSent?verifyOtp:requestOtp),child:Text(otpSent?'تأكيد الدخول':'إرسال رمز التحقق'))),
      const SizedBox(height:10),const Text('سيتم إرسال رمز التحقق على واتساب.',style:TextStyle(fontSize:11,color:Colors.white54)),
    ] else ...[
      if(register)TextField(controller:n,decoration:const InputDecoration(labelText:'الاسم الظاهر',prefixIcon:Icon(Icons.badge_outlined))),if(register)const SizedBox(height:12),
      TextField(controller:u,decoration:const InputDecoration(labelText:'اسم المستخدم',prefixIcon:Icon(Icons.person_outline))),const SizedBox(height:12),TextField(controller:p,obscureText:true,decoration:const InputDecoration(labelText:'كلمة المرور',prefixIcon:Icon(Icons.lock_outline))),
      if(register)const SizedBox(height:12),if(register)TextField(controller:r,decoration:const InputDecoration(labelText:'كود دعوة صديق (اختياري)',prefixIcon:Icon(Icons.card_giftcard))),const SizedBox(height:18),
      SizedBox(width:double.infinity,height:52,child:FilledButton(onPressed:busy?null:submit,child:busy?const CircularProgressIndicator():Text(register?'إنشاء الحساب':'دخول'))),const SizedBox(height:10),
      OutlinedButton.icon(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('زر Google جاهز، ويحتاج GOOGLE_WEB_CLIENT_ID في السيرفر وإعداد OAuth للتطبيق.'))),icon:const Icon(Icons.g_mobiledata),label:const Text('المتابعة باستخدام Google')),const SizedBox(height:4),
      TextButton(onPressed:()=>setState(()=>register=!register),child:Text(register?'لديك حساب؟ دخول':'مستخدم جديد؟ إنشاء حساب')),
    ],
  ]))))));}
}
