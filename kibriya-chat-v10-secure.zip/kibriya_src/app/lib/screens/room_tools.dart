import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:just_audio/just_audio.dart';
import '../core/providers.dart';

class RoomToolsSheet extends ConsumerStatefulWidget {
  final String roomId;
  const RoomToolsSheet({super.key, required this.roomId});
  @override ConsumerState<RoomToolsSheet> createState()=>_RoomToolsSheetState();
}
class _RoomToolsSheetState extends ConsumerState<RoomToolsSheet>{
  final AudioPlayer player=AudioPlayer();
  String? trackName;
  bool playing=false;
  @override void dispose(){player.dispose();super.dispose();}
  Future<void> pickMusic() async {
    final r=await FilePicker.platform.pickFiles(type:FileType.audio);
    if(r?.files.single.path==null)return;
    final path=r!.files.single.path!;
    await player.setFilePath(path); await player.play();
    setState(() { trackName=r.files.single.name; playing=true; });
  }
  Future<void> toggleMusic() async {if(player.playing){await player.pause();setState(()=>playing=false);}else{await player.play();setState(()=>playing=true);}}
  Future<void> uploadBackground() async {
    final x=await ImagePicker().pickImage(source:ImageSource.gallery,maxWidth:1920,imageQuality:85); if(x==null)return;
    try{final url=await ref.read(apiProvider).uploadImage(x.path);await ref.read(apiProvider).dio.post('/api/room/${widget.roomId}/backgrounds',data:{'url':url});if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم حفظ خلفية الهاتف للغرفة')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر رفع الخلفية: $e')));}
  }

  Future<void> _presets() async {final presets=['assets/backgrounds/royal.svg','assets/backgrounds/galaxy.svg','assets/backgrounds/neon.svg','assets/backgrounds/velvet.svg'];final pick=await showModalBottomSheet<String>(context:context,builder:(_)=>ListView(children:[for(final x in presets)ListTile(leading:const Icon(Icons.wallpaper),title:Text(x.split('/').last),onTap:()=>Navigator.pop(context,x))]));if(pick!=null){await ref.read(apiProvider).dio.post('/api/room/${widget.roomId}/backgrounds',data:{'url':pick});if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم اختيار الخلفية الجاهزة')));}}
  Future<void> sendLuckyBag() async {
    final c=TextEditingController(text:'10000'); final l=TextEditingController(text:'10');
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('🎁 كيس الحظ'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:c,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'إجمالي Coins')),TextField(controller:l,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'عدد المستفيدين'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('إنشاء'))]));
    if(ok!=true)return; try{await ref.read(apiProvider).dio.post('/api/room/${widget.roomId}/lucky-bags',data:{'totalCoins':int.tryParse(c.text)||0,'recipientsLimit':int.tryParse(l.text)||10});if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم إطلاق كيس الحظ في الغرفة 🎁')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر إنشاء كيس الحظ: $e')));}
  }

  Future<void> _startPk() async {final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('⚔️ تحدي PK'),content:TextField(controller:c,decoration:const InputDecoration(labelText:'ID الروم المنافس')),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('بدء'))]));if(ok==true&&c.text.trim().isNotEmpty){await ref.read(apiProvider).dio.post('/api/room/${widget.roomId}/pk',data:{'roomBId':c.text.trim(),'targetCoins':100000});if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('بدأ تحدي PK')));}}
  Future<void> _moderate() async {
    try {
      final data=Map<String,dynamic>.from((await ref.read(apiProvider).dio.get('/api/rooms/${widget.roomId}')).data);
      final members=List<dynamic>.from(data['members']??[]);
      if(!mounted)return;
      await showModalBottomSheet(context:context,isScrollControlled:true,builder:(_)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[
        const Text('🛡️ إدارة أعضاء الغرفة',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
        const SizedBox(height:10),
        ...members.map((m)=>Card(child:ListTile(leading:CircleAvatar(child:Text('${m['level']??1}')),title:Text('${m['display_name']}'),subtitle:Text('${m['role']} • المقعد: ${m['seat_index']??'مش قاعد'}'),trailing:PopupMenuButton<String>(onSelected:(v)async{try{if(v=='kick')await ref.read(apiProvider).dio.post('/api/rooms/${widget.roomId}/kick',data:{'userId':'${m['user_id']}'});if(v=='ban')await ref.read(apiProvider).dio.post('/api/rooms/${widget.roomId}/ban',data:{'userId':'${m['user_id']}','reason':'إدارة الغرفة'});if(v=='mute')await ref.read(apiProvider).dio.post('/api/rooms/${widget.roomId}/mute',data:{'userId':'${m['user_id']}','muted':!(m['is_muted']==true)});if(v=='mod')await ref.read(apiProvider).dio.post('/api/rooms/${widget.roomId}/moderators',data:{'userId':'${m['user_id']}','enabled':m['role']!='moderator'});if(mounted)Navigator.pop(context); }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تنفيذ العملية: $e')));}},itemBuilder:(_)=>const [PopupMenuItem(value:'kick',child:Text('طرد من الغرفة')),PopupMenuItem(value:'ban',child:Text('حظر من الغرفة')),PopupMenuItem(value:'mute',child:Text('كتم/فتح الميكروفون')),PopupMenuItem(value:'mod',child:Text('تعيين/إلغاء مشرف'))])))).toList(),
      ])));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تحميل أعضاء الغرفة: $e')));}
  }

  Future<void> _settings() async {final title=TextEditingController(),ann=TextEditingController();bool locked=false,seatsLocked=false;int seats=30;final ok=await showDialog<bool>(context:context,builder:(_)=>StatefulBuilder(builder:(c,set)=>AlertDialog(title:const Text('⚙️ إعدادات الغرفة'),content:SingleChildScrollView(child:Column(children:[TextField(controller:title,decoration:const InputDecoration(labelText:'اسم الغرفة الجديد')),TextField(controller:ann,decoration:const InputDecoration(labelText:'الإعلان')),Slider(value:seats.toDouble(),min:1,max:30,divisions:29,label:'$seats',onChanged:(v)=>set(()=>seats=v.round())),SwitchListTile(value:locked,onChanged:(v)=>set(()=>locked=v),title:const Text('قفل دخول الغرفة')),SwitchListTile(value:seatsLocked,onChanged:(v)=>set(()=>seatsLocked=v),title:const Text('قفل المقاعد'))])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('حفظ'))]));if(ok==true){await ref.read(apiProvider).dio.patch('/api/rooms/${widget.roomId}/settings',data:{if(title.text.trim().isNotEmpty)'title':title.text.trim(),if(ann.text.trim().isNotEmpty)'announcement':ann.text.trim(),'is_locked':locked,'seat_locked':seatsLocked,'max_seats':seats});if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم حفظ إعدادات الغرفة')));}}

  @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.fromLTRB(16,14,16,24),decoration:const BoxDecoration(color:Color(0xFF15101B),borderRadius:BorderRadius.vertical(top:Radius.circular(24))),child:Column(mainAxisSize:MainAxisSize.min,children:[
    const Text('أدوات الغرفة',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:12),
    Wrap(spacing:8,runSpacing:8,children:[
      _btn(Icons.music_note,'موسيقى من الهاتف',pickMusic),_btn(Icons.image,'خلفية من الهاتف',uploadBackground),_btn(Icons.wallpaper,'خلفيات جاهزة',_presets),_btn(Icons.card_giftcard,'كيس الحظ',sendLuckyBag),
      _btn(Icons.rocket_launch,'3 صواريخ',()async{await ref.read(apiProvider).dio.post('/api/room/${widget.roomId}/rockets',data:{'targetCoins':100000});}),
      _btn(Icons.sports_kabaddi,'تحدي PK',_startPk),
      _btn(Icons.shield,'إدارة الأعضاء',_moderate),
      _btn(Icons.settings,'إعدادات الروم',_settings),
    ]),
    if(trackName!=null)Padding(padding:const EdgeInsets.only(top:14),child:Row(children:[const Icon(Icons.library_music),const SizedBox(width:8),Expanded(child:Text(trackName!,maxLines:1,overflow:TextOverflow.ellipsis)),IconButton(onPressed:toggleMusic,icon:Icon(playing?Icons.pause_circle:Icons.play_circle))]))
  ]);
  Widget _btn(IconData i,String t,VoidCallback f)=>FilledButton.tonalIcon(onPressed:f,icon:Icon(i),label:Text(t));
}

class EmoteSheet extends ConsumerWidget {
  final String roomId;
  const EmoteSheet({super.key,required this.roomId});
  @override Widget build(BuildContext context,WidgetRef ref)=>FutureBuilder<ResponseLike>(future:_load(ref),builder:(context,s){if(!s.hasData)return const Padding(padding:EdgeInsets.all(28),child:CircularProgressIndicator());final es=s.data!.items;return Container(padding:const EdgeInsets.all(18),decoration:const BoxDecoration(color:Color(0xFF15101B),borderRadius:BorderRadius.vertical(top:Radius.circular(24))),child:Wrap(spacing:12,runSpacing:12,children:es.map((e)=>InkWell(onTap:()async{await ref.read(apiProvider).dio.post('/api/room/$roomId/emotes',data:{'emoteId':e['id']});if(context.mounted)Navigator.pop(context);},child:Container(width:84,height:84,decoration:BoxDecoration(color:Colors.white10,borderRadius:BorderRadius.circular(18)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(_emoji('${e['code']}'),style:const TextStyle(fontSize:38)),Text('${e['name']}',style:const TextStyle(fontSize:10))])))).toList()));});
  Future<ResponseLike> _load(WidgetRef ref)async=>ResponseLike(List<dynamic>.from((await ref.read(apiProvider).dio.get('/api/room/$roomId/emotes')).data['emotes']));
  String _emoji(String c)=>{'heart':'❤️','fire':'🔥','crown':'👑','star':'⭐','dragon':'🐉','galaxy':'🌌','royal':'🏆'}[c]??'✨';
}
class ResponseLike{final List<dynamic> items;ResponseLike(this.items);}

Future<void> showRoomTools(BuildContext c,String roomId)=>showModalBottomSheet(context:c,isScrollControlled:true,backgroundColor:Colors.transparent,builder:(_)=>RoomToolsSheet(roomId:roomId));
Future<void> showEmotes(BuildContext c,String roomId)=>showModalBottomSheet(context:c,backgroundColor:Colors.transparent,builder:(_)=>EmoteSheet(roomId:roomId));
