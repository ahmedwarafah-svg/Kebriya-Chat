import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';
import '../core/providers.dart';

class ReferralsScreen extends ConsumerStatefulWidget {
  const ReferralsScreen({super.key});
  @override ConsumerState<ReferralsScreen> createState()=>_ReferralsState();
}
class _ReferralsState extends ConsumerState<ReferralsScreen>{
  Map<String,dynamic>? data; bool loading=true;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async { try{final x=await ref.read(apiProvider).referrals();if(mounted)setState(()=>data=x);}finally{if(mounted)setState(()=>loading=false);}}
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('دعوة صديق')),body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(18),children:[
    Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFF4B1830),Color(0xFFC28A2E)])),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('🎁 اكسب من كل دعوة ناجحة',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text('كل مستخدم جديد مؤهل يدخل من رابطك يمنحك ${data?['rewardPerInvite']??500} عملة.',style:const TextStyle(fontSize:15)),const SizedBox(height:18),Text('كودك: ${data?['code']??''}',style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()=>SharePlus.instance.share(ShareParams(text:'👑 انضم إلى كبرياء شات\nكود الدعوة: ${data?['code']}\n${data?['link']}')),icon:const Icon(Icons.share),label:const Text('مشاركة رابط الدعوة')))])),
    const SizedBox(height:18),Row(children:[_Stat('دعوات ناجحة','${data?['invited']??0}'),_Stat('زيارات الرابط','${data?['clicks']??0}'),_Stat('أرباح الدعوات','${data?['earnedCoins']??0}')]),
    const SizedBox(height:18),const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('🛡️ الحماية من الغش: لا تُحسب الدعوة لنفس الحساب، والدعوة مرتبطة بحساب واحد فقط.')))
  ]);}
}
class _Stat extends StatelessWidget{final String a,b;const _Stat(this.a,this.b);@override Widget build(BuildContext c)=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[Text(b,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),Text(a,style:const TextStyle(color:Colors.white54,fontSize:12))]))));}
