class UserModel {
  final String id, username, displayName;
  final String? avatarUrl;
  final int level, vipLevel, svipLevel, chargeLevel, charmLevel;
  final int coins, diamonds, attraction;
  final bool isAdmin;
  UserModel({required this.id, required this.username, required this.displayName, this.avatarUrl, this.level=1, this.vipLevel=0, this.svipLevel=0, this.chargeLevel=1, this.charmLevel=1, this.coins=0, this.diamonds=0, this.attraction=0, this.isAdmin=false});
  factory UserModel.fromJson(Map<String,dynamic> j)=>UserModel(id:'${j['id']}',username:'${j['username']}',displayName:'${j['display_name'] ?? j['displayName'] ?? ''}',avatarUrl:j['avatar_url'],level:j['level']??1,vipLevel:j['vip_level']??0,svipLevel:j['svip_level']??0,chargeLevel:j['charge_level']??1,charmLevel:j['charm_level']??1,coins:j['coins']??0,diamonds:j['diamonds']??0,attraction:j['attraction']??0,isAdmin:j['is_admin']==true);
}

class RoomModel {
  final String id, roomCode, title, ownerId;
  final String? coverUrl, backgroundUrl;
  final int maxSeats, viewers;
  final bool locked;
  RoomModel({required this.id,required this.roomCode,required this.title,required this.ownerId,this.coverUrl,this.backgroundUrl,this.maxSeats=15,this.viewers=0,this.locked=false});
  factory RoomModel.fromJson(Map<String,dynamic> j)=>RoomModel(id:'${j['id']}',roomCode:'${j['room_code']}',title:'${j['title']}',ownerId:'${j['owner_id']}',coverUrl:j['cover_url'],backgroundUrl:j['background_url'],maxSeats:j['max_seats']??15,viewers:j['viewers']??0,locked:j['is_locked']??false);
}
