import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/config.dart';
import '../models/models.dart';

class Api {
  final Dio dio = Dio(BaseOptions(baseUrl: AppConfig.apiBaseUrl, connectTimeout: const Duration(seconds:10), receiveTimeout: const Duration(seconds:15)));
  Api(){ dio.interceptors.add(InterceptorsWrapper(onRequest:(o,h) async { final p=await SharedPreferences.getInstance(); final t=p.getString('token'); if(t!=null) o.headers['Authorization']='Bearer $t'; h.next(o); })); }
  Future<(UserModel,String)> login(String username,String password) async { final r=await dio.post('/api/auth/login',data:{'username':username,'password':password}); final u=UserModel.fromJson(r.data['user']); return (u,r.data['token']); }
  Future<(UserModel,String)> register(String username,String displayName,String password,{String? referralCode}) async { final r=await dio.post('/api/auth/register',data:{'username':username,'displayName':displayName,'password':password,'referralCode':referralCode}); final u=UserModel.fromJson(r.data['user']); return (u,r.data['token']); }

  Future<(UserModel,String)> googleLogin(String idToken) async { final r=await dio.post('/api/auth/google',data:{'idToken':idToken}); final u=UserModel.fromJson(r.data['user']); return (u,r.data['token']); }
  Future<void> requestPhoneOtp(String phone) async { await dio.post('/api/auth/phone/request',data:{'phone':phone}); }
  Future<(UserModel,String)> verifyPhoneOtp(String phone,String otp) async { final r=await dio.post('/api/auth/phone/verify',data:{'phone':phone,'otp':otp}); final u=UserModel.fromJson(r.data['user']); return (u,r.data['token']); }
  Future<String> uploadMedia(String path) async { final f=await MultipartFile.fromFile(path); final r=await dio.post('/api/uploads/media',data:FormData.fromMap({'media':f})); return r.data['url']; }
  Future<List<dynamic>> roomEmotes(String roomId) async => List<dynamic>.from((await dio.get('/api/room/$roomId/emotes')).data['emotes']);
  Future<Map<String,dynamic>> roomStats(String roomId) async => Map<String,dynamic>.from((await dio.get('/api/room/$roomId/stats')).data);
  Future<Map<String,dynamic>> mutualFollow(String userId) async => Map<String,dynamic>.from((await dio.get('/api/follows/mutual/$userId')).data);
  Future<void> follow(String userId) async { await dio.post('/api/follows/$userId'); }
  Future<void> unfollow(String userId) async { await dio.delete('/api/follows/$userId'); }
  Future<void> sendMessage(String userId,String kind,{String? body,String? mediaUrl,int? durationMs}) async { await dio.post('/api/messages',data:{'receiverId':userId,'kind':kind,'body':body,'mediaUrl':mediaUrl,'durationMs':durationMs}); }
  Future<List<dynamic>> messages(String userId) async => List<dynamic>.from((await dio.get('/api/messages/$userId')).data['messages']);

  Future<UserModel> me() async { final r=await dio.get('/api/me'); return UserModel.fromJson(r.data['user']); }
  Future<List<RoomModel>> rooms() async { final r=await dio.get('/api/rooms'); return (r.data['rooms'] as List).map((e)=>RoomModel.fromJson(e)).toList(); }
  Future<Map<String,dynamic>> zegoToken(String roomId) async { final r=await dio.post('/api/zego/token',data:{'roomId':roomId,'canPublish':true}); return Map<String,dynamic>.from(r.data); }
  Future<void> joinRoom(String id) async { await dio.post('/api/rooms/$id/join'); }
  Future<Map<String,dynamic>> roomDetails(String id) async => Map<String,dynamic>.from((await dio.get('/api/rooms/$id')).data);
  Future<void> takeSeat(String id,int index) async { await dio.post('/api/rooms/$id/seat',data:{'seatIndex':index}); }
  Future<List<dynamic>> gifts() async { final r=await dio.get('/api/gifts'); return List<dynamic>.from(r.data['gifts']); }
  Future<List<dynamic>> giftCatalog() async => List<dynamic>.from((await dio.get('/api/gifts')).data['gifts']);
  Future<List<dynamic>> giftRecipients(String roomId) async => List<dynamic>.from((await dio.get('/api/rooms/$roomId/gift-recipients')).data['recipients']);
  Future<Map<String,dynamic>> bag() async => Map<String,dynamic>.from((await dio.get('/api/bag')).data);
  Future<Map<String,dynamic>> wallet() async => Map<String,dynamic>.from((await dio.get('/api/wallet')).data);
  Future<Map<String,dynamic>> sendGiftResult(String roomId,String receiverId,String giftId,int quantity) async { final r=await dio.post('/api/gifts/send',data:{'roomId':roomId,'receiverId':receiverId,'giftId':giftId,'quantity':quantity}); return Map<String,dynamic>.from(r.data); }
  Future<void> sendGift(String roomId,String receiverId,String giftId,int quantity) async { await dio.post('/api/gifts/send',data:{'roomId':roomId,'receiverId':receiverId,'giftId':giftId,'quantity':quantity}); }
  Future<Map<String,dynamic>> wealth() async => Map<String,dynamic>.from((await dio.get('/api/wealth')).data);
  Future<Map<String,dynamic>> levels() async => Map<String,dynamic>.from((await dio.get('/api/levels')).data);
  Future<List<dynamic>> games() async => List<dynamic>.from((await dio.get('/api/games')).data['games']);
  Future<Map<String,dynamic>> playGame(String id) async => Map<String,dynamic>.from((await dio.post('/api/games/$id/play')).data);
  Future<Map<String,dynamic>> cpEvents() async => Map<String,dynamic>.from((await dio.get('/api/cp/events')).data);
  Future<void> claimCp(String id) async { await dio.post('/api/cp/events/$id/claim'); }
  Future<Map<String,dynamic>> adminControlCenter() async => Map<String,dynamic>.from((await dio.get('/api/admin/control-center')).data);
  Future<List<dynamic>> adminTasks() async => List<dynamic>.from((await dio.get('/api/admin/tasks')).data['tasks']);
  Future<List<dynamic>> adminAudit() async => List<dynamic>.from((await dio.get('/api/admin/audit')).data['entries']);
  Future<List<dynamic>> adminGifts() async => List<dynamic>.from((await dio.get('/api/admin/gifts')).data['gifts']);
  Future<void> adminSetUserEconomy(String id,Map<String,dynamic> data) async { await dio.patch('/api/admin/users/$id/economy',data:data); }
  Future<void> adminSetReport(String id,String status) async { await dio.patch('/api/admin/reports/$id',data:{'status':status}); }
  Future<Map<String,dynamic>> adminOwnerSettings() async => Map<String,dynamic>.from((await dio.get('/api/admin/owner-settings')).data);
  Future<Map<String,dynamic>> adminEconomy() async => Map<String,dynamic>.from((await dio.get('/api/admin/economy')).data);
  Future<List<dynamic>> adminGames() async => List<dynamic>.from((await dio.get('/api/admin/games')).data['games']);
  Future<List<dynamic>> adminAchievementGifts() async => List<dynamic>.from((await dio.get('/api/admin/achievement-gifts')).data['gifts']);
  Future<List<dynamic>> adminCpEvents() async => List<dynamic>.from((await dio.get('/api/admin/cp-events')).data['events']);

  Future<List<dynamic>> activities() async { final r=await dio.get('/api/activities'); return List<dynamic>.from(r.data['activities']); }
  Future<Map<String,dynamic>> referrals() async => Map<String,dynamic>.from((await dio.get('/api/referrals')).data);
  Future<List<dynamic>> tasks() async => List<dynamic>.from((await dio.get('/api/tasks')).data['tasks']);
  Future<void> claimTask(String key) async { await dio.post('/api/tasks/$key/claim'); }
  Future<void> rateApp(int rating,String comment) async { await dio.post('/api/ratings',data:{'rating':rating,'comment':comment}); }
  Future<Map<String,dynamic>> myRating() async => Map<String,dynamic>.from((await dio.get('/api/ratings/me')).data);
  Future<Map<String,dynamic>> ratingSummary() async => Map<String,dynamic>.from((await dio.get('/api/ratings/summary')).data);
  Future<Map<String,dynamic>> adminOverview() async => Map<String,dynamic>.from((await dio.get('/api/admin/overview')).data);
  Future<List<dynamic>> adminUsers() async => List<dynamic>.from((await dio.get('/api/admin/users')).data['users']);
  Future<List<dynamic>> adminRooms() async => List<dynamic>.from((await dio.get('/api/admin/rooms')).data['rooms']);
  Future<void> adminUpdateRoom(String id,Map<String,dynamic> data) async { await dio.patch('/api/admin/rooms/$id',data:data); }
  Future<void> adminRoomKick(String roomId,String userId) async { await dio.post('/api/admin/rooms/$roomId/kick',data:{'userId':userId}); }
  Future<void> adminRoomBan(String roomId,String userId,{String reason=''}) async { await dio.post('/api/admin/rooms/$roomId/ban',data:{'userId':userId,'reason':reason}); }
  Future<List<dynamic>> adminReports() async => List<dynamic>.from((await dio.get('/api/admin/reports')).data['reports']);
  Future<void> banUser(String id,bool banned) async { await dio.patch('/api/admin/users/$id/ban',data:{'banned':banned}); }
  Future<String> uploadImage(String path) async { final f=await MultipartFile.fromFile(path); final r=await dio.post('/api/uploads/image',data:FormData.fromMap({'image':f})); return r.data['url']; }

}
