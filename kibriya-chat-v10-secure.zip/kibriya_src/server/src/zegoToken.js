import crypto from 'node:crypto';

// Token04 format follows ZEGO's published server assistant structure:
// "04" + base64(expire:uint64be + ivLen:uint16be + iv + cipherLen:uint16be + cipher)
export function generateToken04(appId, userId, secret, ttlSeconds = 3600, payload = '') {
  if (!Number.isInteger(Number(appId)) || Number(appId) <= 0) throw new Error('Invalid ZEGO_APP_ID');
  if (!userId) throw new Error('Invalid userId');
  if (!secret || Buffer.byteLength(secret) !== 32) throw new Error('ZEGO_SERVER_SECRET must be exactly 32 bytes');
  const now = Math.floor(Date.now() / 1000);
  const expire = now + Number(ttlSeconds);
  const info = { app_id: Number(appId), user_id: userId, ctime: now, expire, nonce: crypto.randomInt(0, 0x7fffffff), payload };
  const iv = Buffer.from(Array.from({length:16}, () => '0123456789abcdefghijklmnopqrstuvwxyz'[crypto.randomInt(36)]));
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(secret), iv);
  const encrypted = Buffer.concat([cipher.update(Buffer.from(JSON.stringify(info))), cipher.final()]);
  const out = Buffer.alloc(8 + 2 + iv.length + 2 + encrypted.length);
  out.writeBigInt64BE(BigInt(expire), 0);
  out.writeUInt16BE(iv.length, 8);
  iv.copy(out, 10);
  out.writeUInt16BE(encrypted.length, 10 + iv.length);
  encrypted.copy(out, 12 + iv.length);
  return '04' + out.toString('base64');
}
