# Kibriya Chat — Security Hardening V9.1

This release hardens the API against common account-takeover, privilege-escalation, abuse and data-exposure problems found during review.

## Critical deployment rules

1. Set `OWNER_USER_ID` to the UUID of the owner's database account. Do not use a username to grant owner/admin access.
2. Set strong, random `JWT_SECRET` and a different `OTP_PEPPER` (32+ bytes recommended).
3. Never put database passwords, JWT secrets, WhatsApp tokens, ZEGOCLOUD server secrets, or the Android signing keystore in the APK or public repository.
4. Use HTTPS for `PUBLIC_BASE_URL` and a specific HTTPS `CORS_ORIGIN` in production.
5. Keep PostgreSQL and Redis private. The provided compose file binds the API to localhost by default and does not publish database/Redis ports.
6. Apply `server/sql/010_security_hardening.sql` after the existing migrations.
7. The owner account must already exist and have `is_admin=true`; `OWNER_USER_ID` then pins the admin control plane to that exact account.

## Changes in this build

- Removed username-based owner/admin provisioning from public registration.
- All admin control-plane routes are pinned to `OWNER_USER_ID` in production.
- JWTs use issuer/audience validation and a shorter default lifetime (7 days).
- API responses no longer expose `password_hash`.
- Added API, login, Google, OTP and upload rate limiting.
- OTP hashes use an HMAC pepper and constant-time comparison.
- Disabled client-controlled task progress (it could be abused to claim rewards).
- Made task and CP reward claims atomic against double-claim races.
- Added room membership checks for room chat, emotes, gifts and room actions.
- Socket room join/typing events now require membership and reject banned users.
- Protected room background creation and PK/lucky-bag/rocket actions.
- Added upload filename randomization, MIME allow-lists and file-signature checks.
- Added security headers and removed `X-Powered-By`.
- Fixed reflected HTML injection in referral landing pages.
- Hardened Docker defaults: no public Postgres/Redis ports and no hardcoded production secrets.
- Added database constraints preventing negative coins/diamonds.

## Important limitation

No application can honestly be called “100% secure” without a production penetration test, dependency audit, infrastructure review, and monitoring. This package is hardened against the issues identified in the source review; production deployment still needs secure server configuration, secrets management, backups, logging/alerting and regular updates.
