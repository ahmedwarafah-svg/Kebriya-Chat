CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username VARCHAR(32) UNIQUE NOT NULL,
  display_name VARCHAR(80) NOT NULL,
  phone VARCHAR(30) UNIQUE,
  password_hash TEXT,
  avatar_url TEXT,
  bio TEXT,
  gender VARCHAR(16),
  level INT NOT NULL DEFAULT 1,
  xp BIGINT NOT NULL DEFAULT 0,
  coins BIGINT NOT NULL DEFAULT 0,
  diamonds BIGINT NOT NULL DEFAULT 0,
  vip_level INT NOT NULL DEFAULT 0,
  agency_id UUID,
  referral_code VARCHAR(24) UNIQUE,
  referred_by UUID REFERENCES users(id),
  referral_count INT NOT NULL DEFAULT 0,
  is_admin BOOLEAN NOT NULL DEFAULT FALSE,
  is_banned BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  room_code VARCHAR(32) UNIQUE NOT NULL,
  title VARCHAR(120) NOT NULL,
  owner_id UUID NOT NULL REFERENCES users(id),
  cover_url TEXT,
  background_url TEXT,
  announcement TEXT,
  max_seats INT NOT NULL DEFAULT 30,
  is_locked BOOLEAN NOT NULL DEFAULT FALSE,
  seat_locked BOOLEAN NOT NULL DEFAULT FALSE,
  status VARCHAR(20) NOT NULL DEFAULT 'live',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS room_members (
  room_id UUID REFERENCES rooms(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  role VARCHAR(20) NOT NULL DEFAULT 'audience',
  seat_index INT,
  is_muted BOOLEAN NOT NULL DEFAULT FALSE,
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(room_id,user_id),
  UNIQUE(room_id,seat_index)
);

CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id UUID NOT NULL REFERENCES users(id),
  room_id UUID REFERENCES rooms(id) ON DELETE CASCADE,
  receiver_id UUID REFERENCES users(id),
  body TEXT NOT NULL,
  message_type VARCHAR(20) NOT NULL DEFAULT 'text',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS gifts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(80) NOT NULL,
  icon_url TEXT,
  price_coins BIGINT NOT NULL,
  animation_url TEXT,
  enabled BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS gift_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id UUID NOT NULL REFERENCES users(id),
  receiver_id UUID NOT NULL REFERENCES users(id),
  room_id UUID REFERENCES rooms(id),
  gift_id UUID NOT NULL REFERENCES gifts(id),
  quantity INT NOT NULL DEFAULT 1,
  total_coins BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(120) NOT NULL,
  description TEXT,
  banner_url TEXT,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  rules JSONB NOT NULL DEFAULT '{}',
  enabled BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS follows (
  follower_id UUID REFERENCES users(id) ON DELETE CASCADE,
  following_id UUID REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(follower_id,following_id)
);

CREATE TABLE IF NOT EXISTS reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id UUID NOT NULL REFERENCES users(id),
  target_user_id UUID REFERENCES users(id),
  room_id UUID REFERENCES rooms(id),
  reason VARCHAR(200) NOT NULL,
  details TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS agencies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(120) NOT NULL,
  owner_id UUID NOT NULL REFERENCES users(id),
  commission_percent NUMERIC(5,2) NOT NULL DEFAULT 10,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS wallet_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  currency VARCHAR(16) NOT NULL,
  amount BIGINT NOT NULL,
  reason VARCHAR(120) NOT NULL,
  reference_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app_ratings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment VARCHAR(500),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS referral_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inviter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  invited_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reward_coins BIGINT NOT NULL DEFAULT 500,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS referral_clicks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referral_code VARCHAR(24) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  task_key VARCHAR(80) NOT NULL,
  progress INT NOT NULL DEFAULT 0,
  target INT NOT NULL DEFAULT 1,
  claimed BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id,task_key)
);

CREATE TABLE IF NOT EXISTS presence_streaks (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  current_streak INT NOT NULL DEFAULT 0,
  best_streak INT NOT NULL DEFAULT 0,
  last_day DATE
);

CREATE INDEX IF NOT EXISTS idx_messages_room_created ON messages(room_id,created_at);
CREATE INDEX IF NOT EXISTS idx_room_members_room ON room_members(room_id);
CREATE INDEX IF NOT EXISTS idx_gifts_enabled ON gifts(enabled);
CREATE INDEX IF NOT EXISTS idx_referral_events_inviter ON referral_events(inviter_id);

INSERT INTO gifts(name,price_coins) SELECT * FROM (VALUES
  ('وردة',10),('قلب',50),('تاج',250),('صاروخ',1000),('حفلة ذهبية',5000)
) AS v(name,price_coins) WHERE NOT EXISTS (SELECT 1 FROM gifts);

INSERT INTO activities(title,description,rules) SELECT * FROM (VALUES
  ('نبض كبرياء','ادخل غرفة صوتية 10 دقائق اليوم لتحصل على XP.', '{"type":"presence","minutes":10}'::jsonb),
  ('جامع الغرف','زر 3 غرف مختلفة اليوم واحصل على مكافأة.', '{"type":"rooms","count":3}'::jsonb),
  ('صانع الحفلة','أنشئ غرفة وابدأ حفلة لمدة 15 دقيقة.', '{"type":"host","minutes":15}'::jsonb),
  ('دعوة صديق','شارك رابطك، وكل مستخدم جديد مؤهل يدخل من دعوتك يمنحك مكافأة.', '{"type":"referral","coins":500}'::jsonb)
) AS v(title,description,rules) WHERE NOT EXISTS (SELECT 1 FROM activities);
