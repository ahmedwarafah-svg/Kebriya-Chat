-- Kibriya Chat V6: full VIP/SVIP progression, starter balance, five in-app games, richer gift catalog
ALTER TABLE users ADD COLUMN IF NOT EXISTS starter_bonus_granted BOOLEAN NOT NULL DEFAULT FALSE;

-- VIP 1..15: each level keeps the previous benefits and adds the listed upgrade.
INSERT INTO vip_levels(id,kind,threshold_coins,title,benefits) VALUES
(1,'VIP',10000,'VIP 1','{"tier":1,"inherits_previous":true,"frame":true,"entry_effect":true,"daily_task_bonus":true}'),
(2,'VIP',30000,'VIP 2','{"tier":2,"inherits_previous":true,"gift_discount_percent":2,"exclusive_badge":true}'),
(3,'VIP',80000,'VIP 3','{"tier":3,"inherits_previous":true,"exclusive_gifts":true,"room_highlight":true}'),
(4,'VIP',150000,'VIP 4','{"tier":4,"inherits_previous":true,"priority_seat":true,"profile_frame_plus":true}'),
(5,'VIP',300000,'VIP 5','{"tier":5,"inherits_previous":true,"priority_support":true,"daily_bonus_coins":250}'),
(6,'VIP',600000,'VIP 6','{"tier":6,"inherits_previous":true,"entry_animation_plus":true,"exclusive_room_theme":true}'),
(7,'VIP',1000000,'VIP 7','{"tier":7,"inherits_previous":true,"gift_combo_cap":100,"extra_bag_slots":25}'),
(8,'VIP',2000000,'VIP 8','{"tier":8,"inherits_previous":true,"exclusive_gift_category":true,"name_color_effect":true}'),
(9,'VIP',3500000,'VIP 9','{"tier":9,"inherits_previous":true,"room_title_badge":true,"daily_bonus_coins":750}'),
(10,'VIP',5000000,'VIP 10','{"tier":10,"inherits_previous":true,"vip_room_access":true,"special_entry_effect":true}'),
(11,'VIP',8000000,'VIP 11','{"tier":11,"inherits_previous":true,"extra_daily_tasks":2,"exclusive_frame":true}'),
(12,'VIP',12000000,'VIP 12','{"tier":12,"inherits_previous":true,"gift_animation_priority":true,"bag_slots_bonus":50}'),
(13,'VIP',20000000,'VIP 13','{"tier":13,"inherits_previous":true,"room_host_badge":true,"daily_bonus_coins":1500}'),
(14,'VIP',35000000,'VIP 14','{"tier":14,"inherits_previous":true,"exclusive_vip_lounge":true,"support_priority":"high"}'),
(15,'VIP',50000000,'VIP 15','{"tier":15,"inherits_previous":true,"royal_frame":true,"royal_entry":true,"daily_bonus_coins":3000}')
ON CONFLICT(id) DO UPDATE SET threshold_coins=EXCLUDED.threshold_coins,title=EXCLUDED.title,benefits=EXCLUDED.benefits;

-- SVIP 1..12. Benefits are cumulative: every level inherits all prior SVIP benefits.
INSERT INTO vip_levels(id,kind,threshold_coins,title,benefits) VALUES
(101,'SVIP',100000000,'SVIP 1','{"tier":1,"inherits_previous":true,"svip_frame":true,"svip_entry":true,"bond_gifts":true,"daily_bonus_coins":5000}'),
(102,'SVIP',200000000,'SVIP 2','{"tier":2,"inherits_previous":true,"special_entry_effect":true,"exclusive_svip_gifts":true,"priority_seat":true}'),
(103,'SVIP',350000000,'SVIP 3','{"tier":3,"inherits_previous":true,"svip_name_effect":true,"cv_access":true,"daily_bonus_coins":10000}'),
(104,'SVIP',500000000,'SVIP 4','{"tier":4,"inherits_previous":true,"premium_support":true,"exclusive_room_theme":true,"bag_slots_bonus":100}'),
(105,'SVIP',750000000,'SVIP 5','{"tier":5,"inherits_previous":true,"svip_lounge":true,"special_gift_animation":true,"daily_bonus_coins":20000}'),
(106,'SVIP',1000000000,'SVIP 6','{"tier":6,"inherits_previous":true,"royal_entry":true,"exclusive_svip_badge":true,"combo_cap":100}'),
(107,'SVIP',1500000000,'SVIP 7','{"tier":7,"inherits_previous":true,"svip_room_creation":true,"custom_room_banner":true,"daily_bonus_coins":30000}'),
(108,'SVIP',2000000000,'SVIP 8','{"tier":8,"inherits_previous":true,"exclusive_cv_events":true,"special_chat_effect":true,"bag_slots_bonus":200}'),
(109,'SVIP',3000000000,'SVIP 9','{"tier":9,"inherits_previous":true,"svip_crown":true,"entry_fireworks":true,"daily_bonus_coins":50000}'),
(110,'SVIP',5000000000,'SVIP 10','{"tier":10,"inherits_previous":true,"private_lounge_access":true,"exclusive_gifts":true,"premium_support":true}'),
(111,'SVIP',7500000000,'SVIP 11','{"tier":11,"inherits_previous":true,"legend_frame":true,"legend_entry":true,"daily_bonus_coins":75000}'),
(112,'SVIP',10000000000,'SVIP 12','{"tier":12,"inherits_previous":true,"supreme_frame":true,"supreme_entry":true,"supreme_gifts":true,"owner_event_access":true,"daily_bonus_coins":100000}')
ON CONFLICT(id) DO UPDATE SET threshold_coins=EXCLUDED.threshold_coins,title=EXCLUDED.title,benefits=EXCLUDED.benefits;

CREATE TABLE IF NOT EXISTS games (
  id VARCHAR(40) PRIMARY KEY,
  title VARCHAR(100) NOT NULL,
  description TEXT,
  icon VARCHAR(20) NOT NULL,
  daily_free_plays INT NOT NULL DEFAULT 3,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  rewards JSONB NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS game_plays (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  game_id VARCHAR(40) NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  reward_coins BIGINT NOT NULL DEFAULT 0,
  result JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_game_plays_user_day ON game_plays(user_id,game_id,created_at DESC);

INSERT INTO games(id,title,description,icon,daily_free_plays,rewards) VALUES
('lucky_wheel','عجلة كبرياء','لف عجلة مجانية واحصل على مكافأة Coins.','🎡',3,'{"rewards":[100,250,500,1000,2500,5000]}'),
('treasure_boxes','صناديق الكنز','اختر صندوقًا واحدًا كل جولة واكشف مفاجأتك.','🎁',3,'{"rewards":[150,300,600,1200,3000]}'),
('royal_dice','نرد الملوك','ارمِ النرد لتحصل على مكافأة حسب النتيجة.','🎲',3,'{"rewards":[100,200,400,800,1600,3200]}'),
('speed_tap','سباق السرعة','اختبر سرعتك واجمع مكافأة الجولة.','⚡',5,'{"rewards":[100,250,500,750,1500]}'),
('pride_guess','خمن رقمك','خمن الرقم السري للجولة لتحصل على جائزة أعلى.','🔮',3,'{"rewards":[200,500,1000,2500,5000]}')
ON CONFLICT(id) DO UPDATE SET title=EXCLUDED.title,description=EXCLUDED.description,icon=EXCLUDED.icon,daily_free_plays=EXCLUDED.daily_free_plays,rewards=EXCLUDED.rewards;

-- New accounts receive STARTER_COINS in server registration code; existing accounts are not credited.

-- Premium gift catalog additions; animation_url can later point to Lottie/WebP/MP4 assets.
INSERT INTO gifts(name,price_coins,category,combo_group,combo_max,min_vip,min_svip,sort_order,metadata)
SELECT * FROM (VALUES
 ('قلب المجرة',150000,'svip','galaxy-heart',20,10,1,120,'{"icon":"💖","style":"premium","animation":"galaxy-heart"}'::jsonb),
 ('تاج العنقاء',300000,'svip','phoenix-crown',10,12,2,130,'{"icon":"👑","style":"premium","animation":"phoenix"}'::jsonb),
 ('مجرة كبرياء',750000,'svip','galaxy',5,15,4,140,'{"icon":"🌌","style":"legendary","animation":"galaxy"}'::jsonb),
 ('انفجار الملوك',1500000,'combo','royal-burst',100,8,0,150,'{"icon":"💥","style":"legendary","animation":"royal-burst"}'::jsonb),
 ('كنز الحظ الملكي',500000,'luck','royal-luck',10,5,0,160,'{"icon":"💎","style":"lucky","animation":"royal-luck","multipliers":[2,3,5,10,20]}'::jsonb),
 ('قلب الارتباط الأبدي',2500000,'svip','eternal-bond',3,0,6,170,'{"icon":"💍","style":"bond","animation":"eternal-bond"}'::jsonb),
 ('تاج CV الأسطوري',5000000,'cv','cv-legend',3,10,5,180,'{"icon":"🏆","style":"cv","animation":"cv-legend"}'::jsonb),
 ('صندوق النجوم',1000000,'luck','star-box',5,7,2,190,'{"icon":"🌟","style":"lucky","animation":"star-box","multipliers":[2,4,8,15]}'::jsonb)
) AS v(name,price_coins,category,combo_group,combo_max,min_vip,min_svip,sort_order,metadata)
WHERE NOT EXISTS (SELECT 1 FROM gifts WHERE gifts.name=v.name);
