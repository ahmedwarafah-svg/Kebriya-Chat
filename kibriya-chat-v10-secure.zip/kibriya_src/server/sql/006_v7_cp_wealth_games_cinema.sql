-- Kibriya Chat V7: CP naming, wealth levels, celebrity/country gifts, extra games, cinema rooms
-- Public terminology: CV is retired; all related user-facing events/gifts are CP.
CREATE TABLE IF NOT EXISTS cp_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), title VARCHAR(120) NOT NULL,
  description TEXT, banner_url TEXT, starts_at TIMESTAMPTZ, ends_at TIMESTAMPTZ,
  target_type VARCHAR(32) NOT NULL DEFAULT 'gift_value', target_value BIGINT NOT NULL DEFAULT 0,
  reward_coins BIGINT NOT NULL DEFAULT 0, reward_xp BIGINT NOT NULL DEFAULT 0,
  enabled BOOLEAN NOT NULL DEFAULT TRUE, rules JSONB NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS cp_event_progress (
  event_id UUID NOT NULL REFERENCES cp_events(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, progress BIGINT NOT NULL DEFAULT 0,
  claimed BOOLEAN NOT NULL DEFAULT FALSE, updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(event_id,user_id)
);
-- Migrate legacy CV rows once.
INSERT INTO cp_events(id,title,description,banner_url,starts_at,ends_at,target_type,target_value,reward_coins,reward_xp,enabled,rules)
SELECT id,REPLACE(title,'CV','CP'),description,banner_url,starts_at,ends_at,target_type,target_value,reward_coins,reward_xp,enabled,rules
FROM cv_events WHERE NOT EXISTS (SELECT 1 FROM cp_events c WHERE c.id=cv_events.id);
INSERT INTO cp_event_progress(event_id,user_id,progress,claimed,updated_at)
SELECT event_id,user_id,progress,claimed,updated_at FROM cv_event_progress
ON CONFLICT(event_id,user_id) DO NOTHING;
UPDATE gifts SET category='cp', metadata=jsonb_set(COALESCE(metadata,'{}'::jsonb),'{label}','"CP"') WHERE category='cv';
UPDATE gifts SET name='تاج CP الأسطوري' WHERE name='تاج CV الأسطوري';
UPDATE cp_events SET title=REPLACE(title,'CV','CP'), rules=jsonb_set(COALESCE(rules,'{}'::jsonb),'{type}','"cp"');

-- Wealth is cumulative outgoing gift value (not current wallet balance).
CREATE TABLE IF NOT EXISTS wealth_levels (
  id INT PRIMARY KEY,
  threshold_coins BIGINT NOT NULL,
  title VARCHAR(80) NOT NULL,
  benefits JSONB NOT NULL DEFAULT '{}'
);
INSERT INTO wealth_levels(id,threshold_coins,title,benefits) VALUES
(1,0,'ثروة 1','{"badge":"bronze"}'),
(2,10000,'ثروة 2','{"badge":"silver","frame":true}'),
(3,50000,'ثروة 3','{"badge":"gold","entry_effect":true}'),
(4,150000,'ثروة 4','{"badge":"ruby","gift_discount":1}'),
(5,500000,'ثروة 5','{"badge":"diamond","special_effect":true}'),
(6,1000000,'ثروة 6','{"badge":"royal","priority":true}'),
(7,2500000,'ثروة 7','{"badge":"royal_plus","exclusive_gift":true}'),
(8,5000000,'ثروة 8','{"badge":"legend","entry_effect":true}'),
(9,10000000,'ثروة 9','{"badge":"legend_plus","exclusive_room_theme":true}'),
(10,25000000,'ثروة 10','{"badge":"supreme","royal_entry":true}'),
(11,50000000,'ثروة 11','{"badge":"mythic","special_lounge":true}'),
(12,100000000,'ثروة 12','{"badge":"mythic_plus","exclusive_gifts":true}'),
(13,250000000,'ثروة 13','{"badge":"immortal","custom_entry":true}'),
(14,500000000,'ثروة 14','{"badge":"immortal_plus","private_lounge":true}'),
(15,1000000000,'ثروة 15','{"badge":"supreme_royal","owner_event_access":true}')
ON CONFLICT(id) DO UPDATE SET threshold_coins=EXCLUDED.threshold_coins,title=EXCLUDED.title,benefits=EXCLUDED.benefits;

-- Achievement/celebrity named gifts and country gifts.
CREATE TABLE IF NOT EXISTS achievement_gifts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  display_name VARCHAR(120) NOT NULL,
  achievement_title VARCHAR(160) NOT NULL,
  gift_id UUID REFERENCES gifts(id) ON DELETE SET NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO gifts(name,price_coins,category,combo_group,combo_max,min_vip,min_svip,sort_order,metadata)
SELECT * FROM (VALUES
 ('أسطورة الشهر','100000','celebrity','celebrity',10,5,0,210,'{"icon":"🌟","style":"celebrity","animation":"celebrity"}'::jsonb),
 ('هدية باسم الإنجاز','250000','celebrity','achievement',5,8,0,220,'{"icon":"🏅","style":"achievement","animation":"achievement"}'::jsonb),
 ('هدية مصر','1000','country','country-egypt',50,0,0,230,'{"icon":"🇪🇬","style":"country","country":"مصر"}'::jsonb),
 ('هدية السعودية','1000','country','country-saudi',50,0,0,231,'{"icon":"🇸🇦","style":"country","country":"السعودية"}'::jsonb),
 ('هدية الإمارات','1000','country','country-uae',50,0,0,232,'{"icon":"🇦🇪","style":"country","country":"الإمارات"}'::jsonb),
 ('هدية المغرب','1000','country','country-morocco',50,0,0,233,'{"icon":"🇲🇦","style":"country","country":"المغرب"}'::jsonb),
 ('هدية الأردن','1000','country','country-jordan',50,0,0,234,'{"icon":"🇯🇴","style":"country","country":"الأردن"}'::jsonb)
) AS v(name,price_coins,category,combo_group,combo_max,min_vip,min_svip,sort_order,metadata)
WHERE NOT EXISTS (SELECT 1 FROM gifts g WHERE g.name=v.name);

INSERT INTO games(id,title,description,icon,daily_free_plays,rewards) VALUES
('ludo','لودو كبرياء','لعبة لودو تسالي بنظام جولات مجانية ومكافآت افتراضية.','🎲',5,'{"rewards":[100,250,500,1000,2500]}'),
('billiards','بليردو كبرياء','بليردو تسالي: جولة سريعة ومكافأة عند إنهاء اللعب.','🎱',5,'{"rewards":[120,300,600,1200,2500]}'),
('dominoes','دومنة تسالي','دومنة خفيفة بجولات قصيرة ومكافآت Coins افتراضية.','🀄',5,'{"rewards":[100,200,400,800,1600]}')
ON CONFLICT(id) DO UPDATE SET title=EXCLUDED.title,description=EXCLUDED.description,icon=EXCLUDED.icon,daily_free_plays=EXCLUDED.daily_free_plays,rewards=EXCLUDED.rewards;
