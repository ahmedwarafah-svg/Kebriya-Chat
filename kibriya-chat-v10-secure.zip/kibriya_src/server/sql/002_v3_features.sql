-- Run this on an existing Kibriya v2 database.
ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_code VARCHAR(24) UNIQUE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS referred_by UUID REFERENCES users(id);
ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_count INT NOT NULL DEFAULT 0;
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS seat_locked BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS app_ratings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5), comment VARCHAR(500), created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS referral_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), inviter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  invited_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE, reward_coins BIGINT NOT NULL DEFAULT 500, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS referral_clicks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), referral_code VARCHAR(24) NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS user_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  task_key VARCHAR(80) NOT NULL, progress INT NOT NULL DEFAULT 0, target INT NOT NULL DEFAULT 1,
  claimed BOOLEAN NOT NULL DEFAULT FALSE, updated_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(user_id,task_key)
);
CREATE TABLE IF NOT EXISTS presence_streaks (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, current_streak INT NOT NULL DEFAULT 0,
  best_streak INT NOT NULL DEFAULT 0, last_day DATE
);

UPDATE users SET referral_code=UPPER(LEFT(username,8)||SUBSTRING(REPLACE(gen_random_uuid()::text,'-','') FROM 1 FOR 8)) WHERE referral_code IS NULL;
