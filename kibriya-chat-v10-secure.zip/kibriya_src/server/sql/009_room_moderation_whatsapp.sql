-- V9: WhatsApp OTP + complete room moderation/admin controls
CREATE TABLE IF NOT EXISTS whatsapp_otps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_e164 VARCHAR(30) NOT NULL,
  otp_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  attempts INT NOT NULL DEFAULT 0,
  used BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_whatsapp_otps_phone_created ON whatsapp_otps(phone_e164, created_at DESC);

CREATE TABLE IF NOT EXISTS room_bans (
  room_id UUID NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  banned_by UUID NOT NULL REFERENCES users(id),
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(room_id,user_id)
);
CREATE INDEX IF NOT EXISTS idx_room_bans_user ON room_bans(user_id);

ALTER TABLE rooms ADD COLUMN IF NOT EXISTS music_url TEXT;
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS music_title TEXT;
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS music_is_playing BOOLEAN NOT NULL DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS idx_room_members_room_seat ON room_members(room_id,seat_index);
CREATE INDEX IF NOT EXISTS idx_rooms_status_created ON rooms(status,created_at DESC);
