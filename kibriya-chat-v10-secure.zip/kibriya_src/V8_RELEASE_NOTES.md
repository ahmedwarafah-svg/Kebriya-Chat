# كبرياء شات — V8

## Added
- Animated room emotes with cumulative VIP 1–15 and SVIP 1–12 unlocks.
- Room Wealth / Attraction / Gifts counters; totals update from every gift transaction.
- Lucky Bags with server-side coin deduction and unique claims.
- 3-rocket room milestone; server tracks support target and broadcasts the launch event.
- PK room challenge endpoints and room controls.
- Expanded room settings: title, announcement, entry lock, seat lock, max seats up to 30.
- Preset background library plus phone-uploaded room backgrounds.
- Local phone music picker/player inside room tools. Broadcasting music to every participant still requires an audio-mixing/publishing provider integration.
- Family creation and group chat API/UI with text, image and voice-message storage.
- Private chat now requires mutual follow, with text/image/voice-message support.
- Google login backend endpoint and phone OTP flow scaffold. Production Google/SMS credentials remain external configuration.
- Media upload endpoint for images/audio.
- CP terminology cleanup in user-facing gift/event data.

## Important production dependencies
- ZEGOCLOUD credentials for live audio.
- Google OAuth client ID and Android/iOS configuration.
- SMS/OTP provider for real phone verification.
- HTTPS/domain and production object storage/CDN when scaling beyond local uploads.
- For room-wide music broadcasting, integrate an audio-mixing/publishing solution; the current phone music tool plays locally on the host device.

## V9 patch — room moderation + WhatsApp OTP
- WhatsApp Cloud API OTP with hashed OTP storage, expiry and attempt/rate limits.
- Room bans, unbans, moderator roles, mute controls and real kick/remove behavior.
- Owner/admin room management endpoints for status, lock, seats, music metadata and moderation.
- Added room music state fields for synchronized client state.
