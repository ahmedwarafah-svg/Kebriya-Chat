# كبرياء شات V4 — Economy & Engagement

هذه النسخة توسّع الهيكل الداخلي إلى نظام اجتماعي/اقتصادي قابل للتوصيل بخدمات الإنتاج لاحقًا.

## Added
- VIP tiers + SVIP tiers + charge levels.
- Attraction/charm statistics.
- Gift catalog: basic, combo, luck, SVIP/relationship, CV.
- Gift bag persisted in PostgreSQL.
- Gift send transaction with coin debit, receiver diamonds, attraction, and compact room counters.
- Luck multiplier metadata/logic: 2x/3x/5x/10x.
- CV event and progress/claim system.
- Owner controls for user economy, reports, gifts, CV events, owner settings.
- Owner economy dashboard.
- Profile details for VIP/SVIP/charge/attraction.
- Fixed gift panel concept over the room with compact counters.
- Daily tasks expanded with gifting, luck, SVIP and CV participation.

## External dependencies still required before public production
- ZEGOCLOUD credentials for real audio.
- Production domain/HTTPS.
- Production object storage/CDN if desired instead of local persistent volume.
- Google Play/App Store accounts.
- Payment provider if real-money coin top-ups are enabled.

## Important
Virtual luck gifts are implemented as in-app virtual rewards only. Real-money gambling is not part of this build.
