# نشر الإنتاج

1. PostgreSQL على سيرفر خاص أو Managed DB.
2. Redis للـpresence والـrate limiting والطوابير.
3. API خلف HTTPS/Nginx.
4. ضع ZEGO_SERVER_SECRET على السيرفر فقط.
5. أنشئ مشروع ZEGOCLOUD مستقل باسم Kibriya Chat.
6. فعّل In-app Chat/Live Audio Room حسب الخدمات التي ستستخدمها.
7. استخدم Token من `/api/zego/token` ولا تضع ServerSecret في APK.
8. أضف FCM/APNs للإشعارات.
9. أضف object storage للصور/الفيديوهات.
10. قبل النشر التجاري: اختبر الشحن/الاسترجاع/المحفظة ومكافحة الغش وسجل التدقيق.
