# بيئة مشروع كبرياء شات V10.1

## المكونات
- Flutter 3.29+ / Dart 3+
- Android Studio + Android SDK + JDK 17 أو أحدث
- Node.js 22 LTS
- PostgreSQL 17
- Redis 7
- Git

> هذه الحزمة تحتوي على كود Flutter وBackend والـassets والـSQL، لكنها لا تحتوي على مجلدات Android/iOS المولدة من Flutter. يتم توليدها بأمر واحد بعد تثبيت Flutter.

## 1) توليد منصات Flutter
```bash
cd app
flutter create --platforms=android,ios .
flutter pub get
```
لو هدفك Android فقط:
```bash
flutter create --platforms=android .
```

## 2) إعداد Backend
```bash
cd server
cp .env.example .env
npm install
```
عدّل القيم السرية في `.env` قبل التشغيل الحقيقي.

## 3) قاعدة البيانات
طبّق ملفات `server/sql/` بالترتيب الرقمي من 001 إلى 010.

مثال:
```bash
for f in server/sql/*.sql; do
  echo "Applying $f"
  psql "$DATABASE_URL" -f "$f"
done
```

## 4) التشغيل المحلي
شغّل PostgreSQL وRedis أولاً، ثم:
```bash
cd server
npm start
```
وفي طرفية أخرى:
```bash
cd app
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8080
```

## 5) الصوت
الصوت يستخدم ZEGOCLOUD. لا تضع `ZEGO_SERVER_SECRET` داخل Flutter. الـServer هو الذي يولد الـToken.

## 6) WhatsApp OTP
يتطلب Meta WhatsApp Cloud API وقالب OTP معتمد، ثم تعبئة:
- WHATSAPP_ACCESS_TOKEN
- WHATSAPP_PHONE_NUMBER_ID
- WHATSAPP_OTP_TEMPLATE
- WHATSAPP_OTP_LANGUAGE

## 7) الإنتاج
قبل الإنتاج يجب ضبط HTTPS وCORS وJWT/OTP secrets وOWNER_USER_ID وZEGOCLOUD وWhatsApp، وعدم استخدام أسرار التطوير.
