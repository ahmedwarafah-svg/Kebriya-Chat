import 'dotenv/config';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import pg from 'pg';
import { Server } from 'socket.io';
import { generateToken04 } from './zegoToken.js';
import { OAuth2Client } from 'google-auth-library';
import crypto from 'node:crypto';

const { Pool } = pg;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: process.env.PGSSL_REJECT_UNAUTHORIZED !== 'false' } : undefined,
  max: Number(process.env.DB_POOL_MAX || 20),
});
const app = express();
const configuredOrigin = String(process.env.CORS_ORIGIN || '').trim();
if (process.env.NODE_ENV === 'production' && !configuredOrigin) throw new Error('CORS_ORIGIN is required in production');
const corsOrigin = configuredOrigin || true;
app.use(cors({ origin: corsOrigin, methods: ['GET','POST','PATCH','PUT','DELETE','OPTIONS'], allowedHeaders: ['Content-Type','Authorization'], credentials: false }));
app.disable('x-powered-by');
app.use((req,res,next)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Permissions-Policy','camera=(), geolocation=(), payment=(), usb=()');
  res.setHeader('Cross-Origin-Opener-Policy','same-origin');
  next();
});
app.use(express.json({ limit: '1mb' }));

const uploadDir = process.env.UPLOAD_DIR || path.resolve(process.cwd(), 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const safeExt = (mime) => ({'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp','image/gif':'.gif','audio/mpeg':'.mp3','audio/mp4':'.m4a','audio/aac':'.aac','audio/wav':'.wav','audio/x-m4a':'.m4a','audio/ogg':'.ogg'})[mime] || '';
const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => cb(null, `${crypto.randomUUID()}${safeExt(file.mimetype)}`),
});
const imageFilter = (_, file, cb) => cb(null, /^image\/(jpeg|png|webp)$/.test(file.mimetype));
const mediaFilter = (_, file, cb) => cb(null, /^(image\/(jpeg|png|webp)|audio\/(mpeg|mp4|aac|wav|x-m4a|ogg))$/.test(file.mimetype));
const upload = multer({ storage, limits: { fileSize: 8 * 1024 * 1024, files: 1 }, fileFilter: imageFilter });
app.use('/uploads', express.static(uploadDir, { maxAge: '7d', index: false, setHeaders: (res) => { res.setHeader('X-Content-Type-Options','nosniff'); res.setHeader('Content-Security-Policy',"default-src 'none'"); res.setHeader('Content-Disposition','inline'); } }));

const httpServer = http.createServer(app);
const io = new Server(httpServer, { cors: { origin: corsOrigin, methods: ['GET','POST'], credentials: false } });
const MAX_SEATS = 30;
const OWNER_USER_ID = String(process.env.OWNER_USER_ID || '').trim();
const PUBLIC_BASE_URL = String(process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '');
const INVITE_REWARD = Number(process.env.INVITE_REWARD_COINS || 500);
const STARTER_COINS = Number(process.env.STARTER_COINS || 1000000);
const JWT_EXPIRES_IN = String(process.env.JWT_EXPIRES_IN || '7d');
if (process.env.NODE_ENV === 'production' && (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32 || process.env.JWT_SECRET === 'CHANGE_THIS')) throw new Error('A strong JWT_SECRET is required in production');
if (process.env.NODE_ENV === 'production' && (!PUBLIC_BASE_URL || !/^https:\/\//i.test(PUBLIC_BASE_URL))) throw new Error('PUBLIC_BASE_URL must use HTTPS in production');

function publicUser(user) {
  if (!user) return null;
  const { password_hash, ...safe } = user;
  return safe;
}
function sign(user) { return jwt.sign({ sub:user.id }, process.env.JWT_SECRET, { expiresIn:JWT_EXPIRES_IN, issuer:'kibriya-chat', audience:'kibriya-app' }); }
async function auth(req,res,next){
  try {
    const raw=String(req.headers.authorization||'');
    if(!raw.startsWith('Bearer ')) return res.status(401).json({error:'unauthorized'});
    const p=jwt.verify(raw.slice(7),process.env.JWT_SECRET,{issuer:'kibriya-chat',audience:'kibriya-app'});
    const {rows}=await pool.query('SELECT * FROM users WHERE id=$1',[p.sub]);
    if(!rows[0]||rows[0].is_banned) return res.status(401).json({error:'unauthorized'});
    req.user=rows[0]; next();
  } catch { return res.status(401).json({error:'unauthorized'}); }
}
function admin(req,res,next){ if(!req.user?.is_admin) return res.status(403).json({error:'admin_only'}); if(OWNER_USER_ID && String(req.user.id)!==OWNER_USER_ID) return res.status(403).json({error:'owner_only'}); if(process.env.NODE_ENV==='production' && !OWNER_USER_ID) return res.status(503).json({error:'owner_not_configured'}); next(); }
function ownerOnly(req,res,next){ if(!OWNER_USER_ID || String(req.user?.id)!==OWNER_USER_ID) return res.status(403).json({error:'owner_only'}); next(); }
function escapeHtml(v){ return String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
const rateBuckets = new Map();
function rateLimit({windowMs=60000,max=60,keyFn=(req)=>req.ip}={}){
  return (req,res,next)=>{
    const now=Date.now(), key=String(keyFn(req)); let b=rateBuckets.get(key);
    if(!b || b.resetAt<=now){ b={count:0,resetAt:now+windowMs}; rateBuckets.set(key,b); }
    b.count++; res.setHeader('RateLimit-Limit',max); res.setHeader('RateLimit-Remaining',Math.max(0,max-b.count));
    if(b.count>max) return res.status(429).json({error:'rate_limited'}); next();
  };
}
setInterval(()=>{const now=Date.now(); for(const [k,v] of rateBuckets) if(v.resetAt<=now) rateBuckets.delete(k);}, 300000).unref();
const OTP_PEPPER = String(process.env.OTP_PEPPER || process.env.JWT_SECRET || '');
if (process.env.NODE_ENV === 'production' && OTP_PEPPER.length < 32) throw new Error('OTP_PEPPER must be configured with a strong secret in production');
function hashOtp(otp){ return crypto.createHmac('sha256', OTP_PEPPER).update(String(otp)).digest('hex'); }
function safeEqualHex(a,b){ try { const aa=Buffer.from(String(a),'hex'), bb=Buffer.from(String(b),'hex'); return aa.length===bb.length && crypto.timingSafeEqual(aa,bb); } catch { return false; } }
function roomAccess(room,userId){ return String(room.owner_id)===String(userId); }
async function canModerateRoom(roomId,userId){ const r=(await pool.query(`SELECT r.owner_id,EXISTS(SELECT 1 FROM room_members m WHERE m.room_id=r.id AND m.user_id=$2 AND m.role IN ('owner','moderator')) can_moderate FROM rooms r WHERE r.id=$1`,[roomId,userId])).rows[0]; return Boolean(r&&(String(r.owner_id)===String(userId)||r.can_moderate)); }
async function roomOwnerOrAdmin(req,res,next){ const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[req.params.id])).rows[0]; if(!room)return res.status(404).json({error:'room_not_found'}); if(!roomAccess(room,req.user.id) && !(req.user.is_admin && OWNER_USER_ID && String(req.user.id)===OWNER_USER_ID))return res.status(403).json({error:'owner_only'}); req.room=room; next(); }
function referralCode(username){ return `${username.slice(0,8).toUpperCase()}${Math.random().toString(36).slice(2,7).toUpperCase()}`.slice(0,24); }
async function credit(userId, amount, reason, referenceId=null){
  await pool.query('UPDATE users SET coins=coins+$1 WHERE id=$2',[amount,userId]);
  await pool.query('INSERT INTO wallet_ledger(user_id,currency,amount,reason,reference_id) VALUES($1,\'coins\',$2,$3,$4)',[userId,amount,reason,referenceId]);
}

app.get('/health',(_,res)=>res.json({ok:true,name:'Kibriya Chat API',version:'10.0-secure',time:new Date().toISOString()}));
app.use('/api/', rateLimit({windowMs:60000,max:180,keyFn:(req)=>`api:${req.ip}`}));

app.post('/api/auth/register', rateLimit({windowMs:60000,max:8,keyFn:(req)=>`register:${req.ip}`}), async (req,res)=>{
  const {username,displayName,password,referralCode:refCode}=req.body;
  if(!username||!displayName||!password||String(password).length<10) return res.status(400).json({error:'invalid_data'});
  const normalized=String(username).trim().toLowerCase();
  try {
    const hash=await bcrypt.hash(password,12);
    const client=await pool.connect();
    try {
      await client.query('BEGIN');
      let inviter=null;
      if(refCode){ inviter=(await client.query('SELECT id FROM users WHERE referral_code=$1',[String(refCode).trim().toUpperCase()])).rows[0]; }
      // SECURITY: never grant admin/owner privileges during public registration.
    // The owner must be pre-provisioned in the database; public registration can never grant admin rights.
    const isOwner=false;
      const inserted=(await client.query('INSERT INTO users(username,display_name,password_hash,referral_code,referred_by,is_admin,coins,starter_bonus_granted) VALUES($1,$2,$3,$4,$5,$6,$7,true) RETURNING id,username,display_name,avatar_url,level,xp,coins,diamonds,vip_level,svip_level,charge_level,attraction,charm_level,referral_code,is_admin',[normalized,displayName,hash,referralCode(normalized),inviter?.id||null,isOwner,STARTER_COINS])).rows[0];
      if(inviter){
        await client.query('UPDATE users SET referral_count=referral_count+1 WHERE id=$1',[inviter.id]);
        const ev=(await client.query('INSERT INTO referral_events(inviter_id,invited_id,reward_coins) VALUES($1,$2,$3) RETURNING id',[inviter.id,inserted.id,INVITE_REWARD])).rows[0];
        await client.query('UPDATE users SET coins=coins+$1 WHERE id=$2',[INVITE_REWARD,inviter.id]);
        await client.query('INSERT INTO wallet_ledger(user_id,currency,amount,reason,reference_id) VALUES($1,\'coins\',$2,\'invite_friend\',$3)',[inviter.id,INVITE_REWARD,ev.id]);
      }
      await client.query('INSERT INTO presence_streaks(user_id) VALUES($1) ON CONFLICT DO NOTHING',[inserted.id]);
      await client.query('COMMIT');
      res.json({user:inserted,token:sign(inserted),referralReward:inviter?INVITE_REWARD:0});
    } catch(e){ await client.query('ROLLBACK'); throw e; } finally { client.release(); }
  } catch(e){ res.status(409).json({error:'username_exists_or_invalid'}); }
});

app.post('/api/auth/login', rateLimit({windowMs:60000,max:10,keyFn:(req)=>`login:${req.ip}`}), async (req,res)=>{
  const {username,password}=req.body;
  const {rows}=await pool.query('SELECT * FROM users WHERE username=$1',[String(username||'').toLowerCase()]);
  if(!rows[0] || !await bcrypt.compare(password, rows[0].password_hash||'')) return res.status(401).json({error:'invalid_credentials'});
  res.json({user:publicUser(rows[0]),token:sign(rows[0])});
});
app.post('/api/auth/google',rateLimit({windowMs:60000,max:10,keyFn:(req)=>`google:${req.ip}`}),async(req,res)=>{
  try{const idToken=String(req.body.idToken||''); if(!idToken)return res.status(400).json({error:'id_token_required'}); const clientId=process.env.GOOGLE_WEB_CLIENT_ID; if(!clientId)return res.status(503).json({error:'google_not_configured'}); const client=new OAuth2Client(clientId); const ticket=await client.verifyIdToken({idToken,audience:clientId}); const p=ticket.getPayload(); if(!p?.sub)return res.status(401).json({error:'invalid_google_token'}); let user=(await pool.query('SELECT * FROM users WHERE id IN (SELECT user_id FROM auth_identities WHERE provider=\'google\' AND provider_subject=$1)',[p.sub])).rows[0]; if(!user){const username=(`g_${String(p.sub).slice(-10)}`).toLowerCase(); const displayName=String(p.name||p.email||'Google User').slice(0,80); user=(await pool.query(`INSERT INTO users(username,display_name,avatar_url,coins,starter_bonus_granted) VALUES($1,$2,$3,$4,true) ON CONFLICT(username) DO UPDATE SET display_name=EXCLUDED.display_name RETURNING *`,[username,displayName,p.picture||null,STARTER_COINS])).rows[0]; await pool.query('INSERT INTO auth_identities(user_id,provider,provider_subject) VALUES($1,\'google\',$2) ON CONFLICT(provider,provider_subject) DO NOTHING',[user.id,p.sub]);} res.json({user:publicUser(user),token:sign(user)}); }catch(e){res.status(401).json({error:'google_auth_failed'});} });
app.post('/api/auth/phone/request',rateLimit({windowMs:600000,max:20,keyFn:(req)=>`otp-ip:${req.ip}`}),async(req,res)=>{
  const phone=String(req.body.phone||'').trim();
  if(!/^\+?[1-9]\d{7,14}$/.test(phone))return res.status(400).json({error:'invalid_phone'});
  if(!process.env.WHATSAPP_ACCESS_TOKEN||!process.env.WHATSAPP_PHONE_NUMBER_ID||!process.env.WHATSAPP_OTP_TEMPLATE) return res.status(503).json({error:'whatsapp_not_configured'});
  const recent=await pool.query("SELECT count(*)::int count FROM whatsapp_otps WHERE phone_e164=$1 AND created_at>now()-interval '10 minutes'",[phone]);
  if(Number(recent.rows[0].count)>=5)return res.status(429).json({error:'otp_rate_limited'});
  const otp=String(crypto.randomInt(100000,1000000));
  await pool.query('UPDATE whatsapp_otps SET used=true WHERE phone_e164=$1 AND used=false',[phone]);
  await pool.query("INSERT INTO whatsapp_otps(phone_e164,otp_hash,expires_at) VALUES($1,$2,now()+interval '5 minutes')",[phone,hashOtp(otp)]);
  const graph=process.env.WHATSAPP_GRAPH_VERSION||'v23.0';
  const url=`https://graph.facebook.com/${graph}/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`;
  const payload={messaging_product:'whatsapp',to:phone,type:'template',template:{name:process.env.WHATSAPP_OTP_TEMPLATE,language:{code:process.env.WHATSAPP_OTP_LANGUAGE||'ar'},components:[{type:'body',parameters:[{type:'text',text:otp}]}]}};
  try{const r=await fetch(url,{method:'POST',headers:{Authorization:`Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});if(!r.ok){const body=await r.text();console.error('WhatsApp OTP failed',body);return res.status(502).json({error:'whatsapp_send_failed'});}}catch(e){console.error(e);return res.status(502).json({error:'whatsapp_send_failed'});}
  res.status(202).json({ok:true,message:'OTP sent on WhatsApp'});
});
app.post('/api/auth/phone/verify',rateLimit({windowMs:600000,max:30,keyFn:(req)=>`otp-verify:${req.ip}`}),async(req,res)=>{
  const phone=String(req.body.phone||'').trim(),otp=String(req.body.otp||'').trim();
  if(!/^\+?[1-9]\d{7,14}$/.test(phone)||!/^\d{6}$/.test(otp))return res.status(400).json({error:'invalid_otp'});
  let valid=false;
  if(process.env.DEV_OTP_MODE==='true') valid=otp===(process.env.DEV_OTP||'123456');
  else { const row=(await pool.query("SELECT * FROM whatsapp_otps WHERE phone_e164=$1 AND used=false AND expires_at>now() ORDER BY created_at DESC LIMIT 1",[phone])).rows[0]; if(row){ if(row.attempts>=5)return res.status(429).json({error:'otp_attempts_exceeded'}); await pool.query('UPDATE whatsapp_otps SET attempts=attempts+1 WHERE id=$1',[row.id]); valid=safeEqualHex(hashOtp(otp),row.otp_hash); if(valid)await pool.query('UPDATE whatsapp_otps SET used=true WHERE id=$1',[row.id]); }}
  if(!valid)return res.status(401).json({error:'invalid_otp'});
  let user=(await pool.query('SELECT * FROM users WHERE phone=$1',[phone])).rows[0];
  if(!user){const username=(`p_${phone.replace(/\D/g,'').slice(-10)}`).slice(0,32);user=(await pool.query(`INSERT INTO users(username,display_name,phone,coins,starter_bonus_granted) VALUES($1,$2,$3,$4,true) RETURNING *`,[username,phone,phone,STARTER_COINS])).rows[0];await pool.query('INSERT INTO auth_identities(user_id,provider,provider_subject,phone_e164) VALUES($1,\'phone\',$2,$3) ON CONFLICT(provider,provider_subject) DO NOTHING',[user.id,phone,phone]);}
  res.json({user:publicUser(user),token:sign(user)});
});
app.get('/api/me',auth,(req,res)=>res.json({user:publicUser(req.user)}));
app.patch('/api/me',auth,async(req,res)=>{
  const displayName = req.body.displayName===undefined ? undefined : String(req.body.displayName).trim().slice(0,80);
  const bio = req.body.bio===undefined ? undefined : String(req.body.bio).slice(0,500);
  const avatarUrl = req.body.avatarUrl===undefined ? undefined : String(req.body.avatarUrl).slice(0,500);
  const {rows}=await pool.query('UPDATE users SET display_name=COALESCE($1,display_name),bio=COALESCE($2,bio),avatar_url=COALESCE($3,avatar_url) WHERE id=$4 RETURNING *',[displayName,bio,avatarUrl,req.user.id]);
  res.json({user:publicUser(rows[0])});
});

app.post('/api/uploads/image',auth,rateLimit({windowMs:60000,max:20,keyFn:(req)=>`upload:${req.user.id}`}),upload.single('image'),validateUploadedFile,(req,res)=>{
  if(!req.file) return res.status(400).json({error:'image_required'});
  res.json({url:`${PUBLIC_BASE_URL}/uploads/${req.file.filename}`,filename:req.file.filename});
});
const mediaUpload=multer({storage,limits:{fileSize:20*1024*1024},fileFilter: mediaFilter});
function validFileSignature(filePath,mime){
  const b=fs.readFileSync(filePath);
  if(mime==='image/jpeg') return b.length>3 && b[0]===0xff && b[1]===0xd8 && b[2]===0xff;
  if(mime==='image/png') return b.length>8 && b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  if(mime==='image/webp') return b.length>12 && b.subarray(0,4).toString()==='RIFF' && b.subarray(8,12).toString()==='WEBP';
  if(mime==='audio/mpeg') return (b.length>=3 && b.subarray(0,3).toString()==='ID3') || (b.length>=2 && b[0]===0xff && (b[1]&0xe0)===0xe0);
  if(mime==='audio/ogg') return b.length>=4 && b.subarray(0,4).toString()==='OggS';
  if(mime==='audio/wav') return b.length>=12 && b.subarray(0,4).toString()==='RIFF' && b.subarray(8,12).toString()==='WAVE';
  if(mime==='audio/mp4' || mime==='audio/x-m4a') return b.length>=12 && b.subarray(4,8).toString()==='ftyp';
  if(mime==='audio/aac') return b.length>=2 && b[0]===0xff && (b[1]&0xf6)===0xf0;
  return false;
}
async function validateUploadedFile(req,res,next){
  if(!req.file)return next();
  try{ if(!validFileSignature(req.file.path,req.file.mimetype)){ await fs.promises.unlink(req.file.path).catch(()=>{}); return res.status(400).json({error:'invalid_file_content'}); } next(); }
  catch{ await fs.promises.unlink(req.file.path).catch(()=>{}); return res.status(400).json({error:'invalid_upload'}); }
}
app.post('/api/uploads/media',auth,rateLimit({windowMs:60000,max:20,keyFn:(req)=>`media-upload:${req.user.id}`}),mediaUpload.single('media'),validateUploadedFile,(req,res)=>{if(!req.file)return res.status(400).json({error:'media_required'});res.json({url:`${PUBLIC_BASE_URL}/uploads/${req.file.filename}`,filename:req.file.filename,mime:req.file.mimetype});});

app.get('/api/rooms',auth,async(req,res)=>{
  const {rows}=await pool.query(`SELECT r.*,u.display_name owner_name,(SELECT count(*) FROM room_members m WHERE m.room_id=r.id) viewers FROM rooms r JOIN users u ON u.id=r.owner_id WHERE r.status='live' ORDER BY viewers DESC, r.created_at DESC`);
  res.json({rooms:rows});
});
app.post('/api/rooms',auth,async(req,res)=>{
  const {title,roomCode,coverUrl,backgroundUrl,maxSeats=30}=req.body;
  const seatCount=Math.min(MAX_SEATS,Math.max(1,Number(maxSeats)||30));
  const {rows}=await pool.query(`INSERT INTO rooms(room_code,title,owner_id,cover_url,background_url,max_seats) VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,[roomCode||`KBR${Date.now()}`,title,req.user.id,coverUrl||null,backgroundUrl||null,seatCount]);
  res.json({room:rows[0]});
});
app.get('/api/rooms/:id',auth,async(req,res)=>{
  const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[req.params.id])).rows[0];
  if(!room) return res.status(404).json({error:'not_found'});
  const members=(await pool.query(`SELECT m.*,u.username,u.display_name,u.avatar_url,u.level,u.vip_level FROM room_members m JOIN users u ON u.id=m.user_id WHERE m.room_id=$1 ORDER BY m.seat_index NULLS LAST`,[room.id])).rows;
  res.json({room,members});
});
app.post('/api/rooms/:id/join',auth,async(req,res)=>{
  const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[req.params.id])).rows[0];
  if(!room) return res.status(404).json({error:'not_found'});
  if(room.is_locked && String(room.owner_id)!==String(req.user.id)) return res.status(423).json({error:'room_locked'});
  const banned=(await pool.query('SELECT 1 FROM room_bans WHERE room_id=$1 AND user_id=$2',[room.id,req.user.id])).rows[0]; if(banned && String(room.owner_id)!==String(req.user.id)) return res.status(403).json({error:'room_banned'});
  await pool.query(`INSERT INTO room_members(room_id,user_id) VALUES($1,$2) ON CONFLICT(room_id,user_id) DO UPDATE SET joined_at=now()`,[req.params.id,req.user.id]);
  await touchPresence(req.user.id);
  io.to(`room:${req.params.id}`).emit('room:member', {type:'join',user:publicUser(req.user)});
  res.json({ok:true});
});
app.post('/api/rooms/:id/seat',auth,async(req,res)=>{
  const roomId=req.params.id; const seat=Number(req.body.seatIndex);
  const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[roomId])).rows[0];
  if(!room) return res.status(404).json({error:'not_found'});
  if(room.seat_locked) return res.status(423).json({error:'seats_locked'});
  if(!Number.isInteger(seat)||seat<0||seat>=Math.min(MAX_SEATS,room.max_seats||MAX_SEATS)) return res.status(400).json({error:'invalid_seat'});
  const client=await pool.connect();
  try { await client.query('BEGIN'); const occupied=(await client.query('SELECT user_id FROM room_members WHERE room_id=$1 AND seat_index=$2 FOR UPDATE',[roomId,seat])).rows[0]; if(occupied && String(occupied.user_id)!==String(req.user.id)){await client.query('ROLLBACK');return res.status(409).json({error:'seat_taken'});} await client.query('UPDATE room_members SET seat_index=NULL WHERE room_id=$1 AND user_id=$2',[roomId,req.user.id]); await client.query('UPDATE room_members SET seat_index=$1 WHERE room_id=$2 AND user_id=$3',[seat,roomId,req.user.id]); await client.query('COMMIT'); io.to(`room:${roomId}`).emit('room:seat',{seatIndex:seat,userId:req.user.id}); res.json({ok:true,seatIndex:seat}); } catch(e){await client.query('ROLLBACK');res.status(500).json({error:'seat_update_failed'});} finally{client.release();}
});
app.delete('/api/rooms/:id/seat',auth,async(req,res)=>{await pool.query('UPDATE room_members SET seat_index=NULL WHERE room_id=$1 AND user_id=$2',[req.params.id,req.user.id]);io.to(`room:${req.params.id}`).emit('room:seat',{userId:req.user.id,seatIndex:null});res.json({ok:true});});
app.post('/api/rooms/:id/seat-lock',auth,async(req,res)=>{const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[req.params.id])).rows[0];if(!room||String(room.owner_id)!==String(req.user.id))return res.status(403).json({error:'owner_only'});const locked=Boolean(req.body.locked);await pool.query('UPDATE rooms SET seat_locked=$1 WHERE id=$2',[locked,room.id]);io.to(`room:${room.id}`).emit('room:seat_lock',{locked});res.json({ok:true,locked});});
app.post('/api/rooms/:id/kick',auth,async(req,res)=>{const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[req.params.id])).rows[0];if(!room)return res.status(404).json({error:'room_not_found'});if(!await canModerateRoom(room.id,req.user.id))return res.status(403).json({error:'moderator_only'});const target=String(req.body.userId||'');if(!target||target===String(room.owner_id))return res.status(400).json({error:'invalid_target'});const targetRole=(await pool.query('SELECT role FROM room_members WHERE room_id=$1 AND user_id=$2',[room.id,target])).rows[0]?.role;if(targetRole==='owner'||targetRole==='moderator'&&String(req.user.id)!==String(room.owner_id))return res.status(403).json({error:'protected_member'});await pool.query('DELETE FROM room_members WHERE room_id=$1 AND user_id=$2',[room.id,target]);io.to(`room:${room.id}`).emit('room:kick',{userId:target});res.json({ok:true});});
app.post('/api/rooms/:id/ban',auth,async(req,res)=>{const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[req.params.id])).rows[0];if(!room)return res.status(404).json({error:'room_not_found'});if(!await canModerateRoom(room.id,req.user.id))return res.status(403).json({error:'moderator_only'});const target=String(req.body.userId||'');if(!target||target===String(room.owner_id))return res.status(400).json({error:'invalid_target'});const targetRole=(await pool.query('SELECT role FROM room_members WHERE room_id=$1 AND user_id=$2',[room.id,target])).rows[0]?.role;if(targetRole==='owner'||targetRole==='moderator'&&String(req.user.id)!==String(room.owner_id))return res.status(403).json({error:'protected_member'});await pool.query('INSERT INTO room_bans(room_id,user_id,banned_by,reason) VALUES($1,$2,$3,$4) ON CONFLICT(room_id,user_id) DO UPDATE SET banned_by=EXCLUDED.banned_by,reason=EXCLUDED.reason,created_at=now()',[room.id,target,req.user.id,String(req.body.reason||'')]);await pool.query('DELETE FROM room_members WHERE room_id=$1 AND user_id=$2',[room.id,target]);io.to(`room:${room.id}`).emit('room:ban',{userId:target});res.json({ok:true});});
app.post('/api/rooms/:id/unban',auth,async(req,res)=>{const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[req.params.id])).rows[0];if(!room)return res.status(404).json({error:'room_not_found'});if(!await canModerateRoom(room.id,req.user.id))return res.status(403).json({error:'moderator_only'});await pool.query('DELETE FROM room_bans WHERE room_id=$1 AND user_id=$2',[room.id,String(req.body.userId||'')]);res.json({ok:true});});
app.post('/api/rooms/:id/mute',auth,async(req,res)=>{const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[req.params.id])).rows[0];if(!room)return res.status(404).json({error:'room_not_found'});if(!await canModerateRoom(room.id,req.user.id))return res.status(403).json({error:'moderator_only'});const target=String(req.body.userId||''),muted=Boolean(req.body.muted);await pool.query('UPDATE room_members SET is_muted=$1 WHERE room_id=$2 AND user_id=$3',[muted,room.id,target]);io.to(`room:${room.id}`).emit('room:mute',{userId:target,muted});res.json({ok:true,muted});});
app.post('/api/rooms/:id/moderators',auth,roomOwnerOrAdmin,async(req,res)=>{const target=String(req.body.userId||''),enabled=req.body.enabled!==false;if(!target)return res.status(400).json({error:'missing_user'});if(enabled)await pool.query("UPDATE room_members SET role='moderator' WHERE room_id=$1 AND user_id=$2",[req.params.id,target]);else await pool.query("UPDATE room_members SET role='audience' WHERE room_id=$1 AND user_id=$2 AND role='moderator'",[req.params.id,target]);io.to(`room:${req.params.id}`).emit('room:moderator',{userId:target,enabled});res.json({ok:true,enabled});});
app.post('/api/rooms/:id/message',auth,async(req,res)=>{const member=(await pool.query('SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2',[req.params.id,req.user.id])).rows[0];if(!member)return res.status(403).json({error:'room_membership_required'});const kind=String(req.body.kind||'text');const body=String(req.body.body||'').trim().slice(0,1000);if(!body||!['text','sticker'].includes(kind))return res.status(400).json({error:'invalid_message'});const {rows}=await pool.query('INSERT INTO messages(sender_id,room_id,body,message_type) VALUES($1,$2,$3,$4) RETURNING *',[req.user.id,req.params.id,body,kind]);io.to(`room:${req.params.id}`).emit('chat:message',{...rows[0],sender:req.user.display_name});res.json({message:rows[0]});});

app.get('/api/gifts',auth,async(_,res)=>res.json({gifts:(await pool.query('SELECT * FROM gifts WHERE enabled=true ORDER BY category,sort_order,price_coins')).rows}));
app.get('/api/rooms/:id/gift-recipients',auth,async(req,res)=>{
  const room= (await pool.query('SELECT id FROM rooms WHERE id=$1',[req.params.id])).rows[0];
  if(!room)return res.status(404).json({error:'room_not_found'});
  const rows=(await pool.query(`SELECT m.user_id,u.display_name,u.avatar_url,u.level,u.vip_level,u.svip_level,m.seat_index
    FROM room_members m JOIN users u ON u.id=m.user_id WHERE m.room_id=$1 AND m.user_id<>$2 ORDER BY m.seat_index NULLS LAST,u.display_name`,[req.params.id,req.user.id])).rows;
  res.json({recipients:rows});
});
app.get('/api/bag',auth,async(req,res)=>{
  const rows=(await pool.query(`SELECT b.gift_id,b.quantity,g.name,g.icon_url,g.price_coins,g.category,g.metadata FROM user_bag b JOIN gifts g ON g.id=b.gift_id WHERE b.user_id=$1 AND b.quantity>0 ORDER BY b.updated_at DESC`,[req.user.id])).rows;
  res.json({capacity:req.user.bag_capacity||50,items:rows});
});
app.get('/api/wallet',auth,async(req,res)=>{
  const u=(await pool.query('SELECT coins,diamonds,charge_level,attraction,charm_level,vip_level,svip_level FROM users WHERE id=$1',[req.user.id])).rows[0];
  const ledger=(await pool.query('SELECT currency,amount,reason,created_at FROM wallet_ledger WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50',[req.user.id])).rows;
  res.json({wallet:u,ledger});
});
app.post('/api/gifts/send',auth,async(req,res)=>{
  const {roomId,receiverId,giftId,quantity=1}=req.body;
  const q=Math.max(1,Math.min(100,Number(quantity)||1));
  if(!roomId||!receiverId||!giftId)return res.status(400).json({error:'missing_gift_fields'});
  const gift=(await pool.query('SELECT * FROM gifts WHERE id=$1 AND enabled=true',[giftId])).rows[0];
  if(!gift)return res.status(404).json({error:'gift_not_found'});
  if(String(receiverId)===String(req.user.id))return res.status(400).json({error:'cannot_gift_self'});
  const senderMember=(await pool.query('SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2',[roomId,req.user.id])).rows[0];
  if(!senderMember)return res.status(403).json({error:'sender_not_in_room'});
  const roomMember=(await pool.query('SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2',[roomId,receiverId])).rows[0];
  if(!roomMember)return res.status(409).json({error:'receiver_not_in_room'});
  if(Number(req.user.vip_level||0)<Number(gift.min_vip||0) || Number(req.user.svip_level||0)<Number(gift.min_svip||0)) return res.status(403).json({error:'vip_required'});
  const maxCombo=Math.max(1,Number(gift.combo_max||1));
  if(q>maxCombo)return res.status(400).json({error:'quantity_exceeds_combo_limit',maxCombo});
  const total=Number(gift.price_coins)*q;
  let luckyMultiplier=1;
  if(gift.category==='luck'){
    const r=Math.random(); luckyMultiplier=r<0.02?10:r<0.08?5:r<0.22?3:2;
  }
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const sender=(await client.query('SELECT coins FROM users WHERE id=$1 FOR UPDATE',[req.user.id])).rows[0];
    if(Number(sender.coins)<total){await client.query('ROLLBACK');return res.status(409).json({error:'insufficient_coins',coinsBefore:Number(sender.coins),requiredCoins:total});}
    const before=Number(sender.coins), after=before-total;
    await client.query('UPDATE users SET coins=coins-$1 WHERE id=$2',[total,req.user.id]);
    const receiverDiamonds=total*luckyMultiplier;
    await client.query('UPDATE users SET diamonds=diamonds+$1,attraction=attraction+$2,charm_level=GREATEST(charm_level,1+FLOOR((attraction+$2)/10000)::int) WHERE id=$3',[receiverDiamonds,total,receiverId]);
    const tx=(await client.query(`INSERT INTO gift_transactions(sender_id,receiver_id,room_id,gift_id,quantity,total_coins,lucky_multiplier,sender_coins_before,sender_coins_after,delivery_mode)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,'burst') RETURNING id`,[req.user.id,receiverId,roomId,gift.id,q,total,luckyMultiplier,before,after])).rows[0];
    await client.query("INSERT INTO wallet_ledger(user_id,currency,amount,reason,reference_id) VALUES($1,'coins',$2,'gift_sent',$3),($4,'diamonds',$5,'gift_received',$3)",[req.user.id,-total,tx.id,receiverId,receiverDiamonds]);
    await client.query(`INSERT INTO user_bag(user_id,gift_id,quantity) VALUES($1,$2,$3) ON CONFLICT(user_id,gift_id) DO UPDATE SET quantity=user_bag.quantity+EXCLUDED.quantity,updated_at=now()`,[receiverId,gift.id,q]);
    if(gift.category==='cp') await client.query(`INSERT INTO cp_event_progress(event_id,user_id,progress) SELECT id,$1,$2 FROM cp_events WHERE enabled=true AND (starts_at IS NULL OR starts_at<=now()) AND (ends_at IS NULL OR ends_at>=now()) AND target_type='gift_value' ON CONFLICT(event_id,user_id) DO UPDATE SET progress=cp_event_progress.progress+EXCLUDED.progress,updated_at=now()`,[receiverId,total]);
    if(gift.category==='luck') await client.query(`INSERT INTO user_tasks(user_id,task_key,progress,target) VALUES($1,'luck_spin',1,1) ON CONFLICT(user_id,task_key) DO UPDATE SET progress=1,updated_at=now()`,[req.user.id]);
    if(gift.category==='svip') await client.query(`INSERT INTO user_tasks(user_id,task_key,progress,target) VALUES($1,'svip_support',1,1) ON CONFLICT(user_id,task_key) DO UPDATE SET progress=1,updated_at=now()`,[req.user.id]);
    await client.query(`INSERT INTO user_tasks(user_id,task_key,progress,target) VALUES($1,'daily_gift',1,1) ON CONFLICT(user_id,task_key) DO UPDATE SET progress=1,updated_at=now()`,[req.user.id]);
    await client.query(`INSERT INTO room_stats(room_id,total_coins,total_gifts,total_diamonds,total_attraction) VALUES($1,$2,$3,$4,$5) ON CONFLICT(room_id) DO UPDATE SET total_coins=room_stats.total_coins+$2,total_gifts=room_stats.total_gifts+$3,total_diamonds=room_stats.total_diamonds+$4,total_attraction=room_stats.total_attraction+$5,updated_at=now()`,[roomId,total,q,receiverDiamonds,total]);
    const rocket=(await client.query(`UPDATE room_rockets SET progress_coins=LEAST(target_coins,progress_coins+$2) WHERE room_id=$1 AND triggered=false RETURNING *`,[roomId,total])).rows[0];
    if(rocket && Number(rocket.progress_coins)>=Number(rocket.target_coins)){await client.query('UPDATE room_rockets SET triggered=true WHERE id=$1',[rocket.id]);setImmediate(()=>io.to(`room:${roomId}`).emit('room:rockets',{count:3,roomId,targetCoins:rocket.target_coins}));}
    await client.query('COMMIT');
    await pool.query("INSERT INTO owner_audit_log(owner_id,action,target_type,target_id,payload) VALUES($1,'gift_send','gift_transaction',$2,$3)",[req.user.id,tx.id,{receiverId,giftId:gift.id,quantity:q,totalCoins:total}]).catch(()=>{});
    io.to(`room:${roomId}`).emit('gift:sent',{senderId:req.user.id,receiverId,giftId:gift.id,quantity:q,totalCoins:total,category:gift.category,luckyMultiplier,senderCoinsBefore:before,senderCoinsAfter:after,deliveryMode:'burst'});
    res.json({ok:true,totalCoins:total,receiverDiamonds,luckyMultiplier,gift,quantity:q,senderCoinsBefore:before,senderCoinsAfter:after});
  }catch(e){await client.query('ROLLBACK');res.status(500).json({error:'gift_send_failed'});}finally{client.release();}
});
app.get('/api/wealth',auth,async(req,res)=>{
  const total=Number((await pool.query("SELECT COALESCE(sum(total_coins),0)::bigint total FROM gift_transactions WHERE sender_id=$1",[req.user.id])).rows[0].total||0);
  const levels=(await pool.query('SELECT * FROM wealth_levels ORDER BY id')).rows;
  let current=levels[0], next=null;
  for(let i=0;i<levels.length;i++){ if(total>=Number(levels[i].threshold_coins)) current=levels[i]; else {next=levels[i];break;} }
  const base=Number(current.threshold_coins||0), nextThreshold=next?Number(next.threshold_coins):base;
  const progress=next?Math.min(1,Math.max(0,(total-base)/(nextThreshold-base))):1;
  res.json({totalSupportedCoins:total,currentLevel:current,nextLevel:next,progress,remainingCoins:Math.max(0,nextThreshold-total),levels});
});
app.get('/api/levels',auth,async(_,res)=>{const [vip,charge]=await Promise.all([pool.query("SELECT * FROM vip_levels ORDER BY id"),pool.query('SELECT * FROM charge_levels ORDER BY id')]);res.json({vip:vip.rows,charge:charge.rows});});
app.get('/api/cosmetics',auth,async(req,res)=>{const role=req.user.is_admin?'super_admin':(req.user.staff_role||'__none__');const items=(await pool.query('SELECT * FROM cosmetic_catalog WHERE enabled=true AND (role_required IS NULL OR role_required=$1) AND min_vip<=$2 AND min_svip<=$3 ORDER BY kind,sort_order',[role,Number(req.user.vip_level||0),Number(req.user.svip_level||0)])).rows;const selected=(await pool.query('SELECT * FROM user_cosmetics WHERE user_id=$1',[req.user.id])).rows[0]||{profile_frame_key:null,entry_effect_key:null,chat_frame_key:null,room_background_key:null};res.json({role,staffRole:req.user.staff_role||null,items,selected});});
app.patch('/api/cosmetics/select',auth,async(req,res)=>{const kind=String(req.body.kind||'');const key=req.body.key==null?null:String(req.body.key);const col={profile_frame:'profile_frame_key',role_frame:'profile_frame_key',entry_effect:'entry_effect_key',chat_frame:'chat_frame_key',room_background:'room_background_key'}[kind];if(!col)return res.status(400).json({error:'invalid_cosmetic_kind'});if(key!==null){const item=(await pool.query('SELECT * FROM cosmetic_catalog WHERE item_key=$1 AND enabled=true',[key])).rows[0];if(!item)return res.status(404).json({error:'cosmetic_not_found'});const role=req.user.is_admin?'super_admin':(req.user.staff_role||null);if(item.role_required&&item.role_required!==role)return res.status(403).json({error:'role_required'});if(Number(req.user.vip_level||0)<Number(item.min_vip||0)||Number(req.user.svip_level||0)<Number(item.min_svip||0))return res.status(403).json({error:'vip_required'});}await pool.query(`INSERT INTO user_cosmetics(user_id,${col},updated_at) VALUES($1,$2,now()) ON CONFLICT(user_id) DO UPDATE SET ${col}=EXCLUDED.${col},updated_at=now()`,[req.user.id,key]);res.json({ok:true,selected:(await pool.query('SELECT * FROM user_cosmetics WHERE user_id=$1',[req.user.id])).rows[0]});});
app.patch('/api/admin/users/:id/staff-role',auth,admin,async(req,res)=>{const role=req.body.role==null?null:String(req.body.role);const allowed=['super_admin','customer_service','event_room','agency_supervisor','new_agency','host_agent','bd'];if(role!==null&&!allowed.includes(role))return res.status(400).json({error:'invalid_staff_role'});const row=(await pool.query('UPDATE users SET staff_role=$1 WHERE id=$2 RETURNING id,username,staff_role',[role,req.params.id])).rows[0];if(!row)return res.status(404).json({error:'user_not_found'});res.json({user:row});});

app.get('/api/games',auth,async(_,res)=>{const rows=(await pool.query('SELECT * FROM games WHERE enabled=true ORDER BY id')).rows;res.json({games:rows});});
app.post('/api/games/:id/play',auth,async(req,res)=>{const game=(await pool.query('SELECT * FROM games WHERE id=$1 AND enabled=true',[req.params.id])).rows[0];if(!game)return res.status(404).json({error:'game_not_found'});const used=Number((await pool.query("SELECT count(*)::int count FROM game_plays WHERE user_id=$1 AND game_id=$2 AND created_at>=current_date",[req.user.id,game.id])).rows[0].count);if(used>=Number(game.daily_free_plays))return res.status(429).json({error:'daily_plays_exhausted',dailyFreePlays:game.daily_free_plays});const rewards=Array.isArray(game.rewards?.rewards)?game.rewards.rewards.map(Number):[100];const reward=rewards[Math.floor(Math.random()*rewards.length)];const result={rewardCoins:reward,playNumber:used+1};await pool.query('INSERT INTO game_plays(user_id,game_id,reward_coins,result) VALUES($1,$2,$3,$4)',[req.user.id,reward,result]);await credit(req.user.id,reward,`game:${game.id}`);res.json({ok:true,gameId:game.id,rewardCoins:reward,remainingPlays:Number(game.daily_free_plays)-used-1,result});});
app.get('/api/admin/games',auth,admin,async(_,res)=>res.json({games:(await pool.query('SELECT * FROM games ORDER BY id')).rows}));
app.get('/api/admin/achievement-gifts',auth,admin,async(_,res)=>res.json({gifts:(await pool.query(`SELECT a.*,u.display_name as user_display_name,g.name as gift_name FROM achievement_gifts a LEFT JOIN users u ON u.id=a.user_id LEFT JOIN gifts g ON g.id=a.gift_id ORDER BY a.created_at DESC LIMIT 100`)).rows}));
app.post('/api/admin/achievement-gifts',auth,admin,async(req,res)=>{const {userId,displayName,achievementTitle,giftId}=req.body;if(!displayName||!achievementTitle)return res.status(400).json({error:'missing_fields'});const row=(await pool.query('INSERT INTO achievement_gifts(user_id,display_name,achievement_title,gift_id) VALUES($1,$2,$3,$4) RETURNING *',[userId||null,displayName,achievementTitle,giftId||null])).rows[0];res.json({gift:row});});

app.get('/api/cp/events',auth,async(req,res)=>{const events=(await pool.query(`SELECT e.*,COALESCE(p.progress,0) progress,COALESCE(p.claimed,false) claimed FROM cp_events e LEFT JOIN cp_event_progress p ON p.event_id=e.id AND p.user_id=$1 WHERE e.enabled=true ORDER BY e.starts_at NULLS LAST`,[req.user.id])).rows;res.json({events});});
app.post('/api/cp/events/:id/claim',auth,async(req,res)=>{const p=(await pool.query('SELECT p.*,e.reward_coins,e.reward_xp,e.target_value FROM cp_event_progress p JOIN cp_events e ON e.id=p.event_id WHERE p.event_id=$1 AND p.user_id=$2',[req.params.id,req.user.id])).rows[0];if(!p||p.claimed||Number(p.progress)<Number(p.target_value))return res.status(409).json({error:'not_ready'});const claimed=(await pool.query('UPDATE cp_event_progress SET claimed=true WHERE event_id=$1 AND user_id=$2 AND claimed=false RETURNING event_id',[req.params.id,req.user.id])).rows[0];if(!claimed)return res.status(409).json({error:'already_claimed'});await credit(req.user.id,Number(p.reward_coins),'cp_event',req.params.id);await pool.query('UPDATE users SET xp=xp+$1 WHERE id=$2',[Number(p.reward_xp),req.user.id]);res.json({ok:true,rewardCoins:p.reward_coins,rewardXp:p.reward_xp});});
app.get('/api/activities',auth,async(_,res)=>res.json({activities:(await pool.query('SELECT * FROM activities WHERE enabled=true ORDER BY starts_at NULLS LAST')).rows}));

async function touchPresence(userId){
  const today=new Date().toISOString().slice(0,10);
  const row=(await pool.query('SELECT * FROM presence_streaks WHERE user_id=$1',[userId])).rows[0];
  if(!row){await pool.query('INSERT INTO presence_streaks(user_id,current_streak,best_streak,last_day) VALUES($1,1,1,$2)',[userId,today]);return;}
  if(row.last_day===today)return;
  const y=new Date();y.setUTCDate(y.getUTCDate()-1);const yesterday=y.toISOString().slice(0,10);const streak=row.last_day===yesterday?row.current_streak+1:1;
  await pool.query('UPDATE presence_streaks SET current_streak=$1,best_streak=GREATEST(best_streak,$1),last_day=$2 WHERE user_id=$3',[streak,today,userId]);
  await pool.query('UPDATE users SET xp=xp+10,level=GREATEST(level,1+FLOOR((xp+10)/100)::int) WHERE id=$1',[userId]);
}
app.get('/api/presence',auth,async(req,res)=>{await touchPresence(req.user.id);const row=(await pool.query('SELECT * FROM presence_streaks WHERE user_id=$1',[req.user.id])).rows[0];res.json(row);});

app.get('/api/referrals',auth,async(req,res)=>{const u=(await pool.query('SELECT referral_code,referral_count,coins FROM users WHERE id=$1',[req.user.id])).rows[0];const clicks=(await pool.query('SELECT count(*)::int count FROM referral_clicks WHERE referral_code=$1',[u.referral_code])).rows[0].count;const earned=(await pool.query('SELECT COALESCE(sum(reward_coins),0)::bigint total FROM referral_events WHERE inviter_id=$1',[req.user.id])).rows[0].total;res.json({code:u.referral_code,link:`${PUBLIC_BASE_URL}/r/${u.referral_code}`,invited:u.referral_count,clicks,earnedCoins:earned,rewardPerInvite:INVITE_REWARD});});
app.get('/r/:code',async(req,res)=>{await pool.query('INSERT INTO referral_clicks(referral_code) VALUES($1)',[String(req.params.code).toUpperCase()]);const code=escapeHtml(String(req.params.code).toUpperCase().slice(0,24)); res.type('html').send(`<meta name="viewport" content="width=device-width,initial-scale=1"><title>كبرياء شات</title><body style="font-family:Arial;text-align:center;background:#07111f;color:white;padding:60px"><h1>👑 كبرياء شات</h1><p>تم تسجيل رابط الدعوة. افتح التطبيق وأنشئ حسابًا باستخدام كود الدعوة.</p><p>كود الدعوة: <b>${code}</b></p></body>`);});

app.get('/api/tasks',auth,async(req,res)=>{
  const tasks=[
    {key:'daily_presence',title:'نبض الحضور',description:'ادخل غرفة صوتية اليوم',target:1,reward:100},
    {key:'visit_rooms',title:'جولة كبرياء',description:'زر 3 غرف مختلفة',target:3,reward:150},
    {key:'invite_friend',title:'دعوة صديق',description:`كل مستخدم جديد مؤهل عبر دعوتك = ${INVITE_REWARD} عملة، ومع أول دعوة مكتملة مكافأة مهمة إضافية.`,target:1,reward:250},
    {key:'rate_app',title:'رأيك يهمنا',description:'قيّم التطبيق من صفحة الحساب',target:1,reward:50},
    {key:'daily_gift',title:'هدية اليوم',description:'أرسل هدية واحدة داخل حفلة',target:1,reward:75},
    {key:'luck_spin',title:'حظ كبرياء',description:'استخدم هدية حظ واحدة',target:1,reward:100},
    {key:'svip_support',title:'دعم SVIP',description:'أرسل هدية SVIP أو ارتباط',target:1,reward:300},
    {key:'cp_event',title:'CP Challenge',description:'شارك في حدث CP وارفع تقدمك',target:1,reward:250},
  ];
  const existing=(await pool.query('SELECT task_key,progress,target,claimed FROM user_tasks WHERE user_id=$1',[req.user.id])).rows;
  const map=new Map(existing.map(x=>[x.task_key,x]));
  const referrals=Number((await pool.query('SELECT referral_count FROM users WHERE id=$1',[req.user.id])).rows[0]?.referral_count||0);
  const presence=Boolean((await pool.query('SELECT last_day FROM presence_streaks WHERE user_id=$1 AND last_day=current_date',[req.user.id])).rows[0]);
  const roomsToday=Number((await pool.query("SELECT count(DISTINCT room_id)::int count FROM room_members WHERE user_id=$1 AND joined_at>=current_date",[req.user.id])).rows[0]?.count||0);
  const rows=tasks.map(t=>{const base=map.get(t.key)||{progress:0,claimed:false}; let progress=base.progress; if(t.key==='invite_friend') progress=referrals; if(t.key==='daily_presence') progress=presence?1:0; if(t.key==='visit_rooms') progress=roomsToday; return {...t,...base,progress};});
  res.json({tasks:rows});
});
app.post('/api/tasks/:key/claim',auth,async(req,res)=>{
  const definitions={daily_presence:['نبض الحضور',1,100],visit_rooms:['جولة كبرياء',3,150],invite_friend:['دعوة صديق',1,250],rate_app:['رأيك يهمنا',1,50],daily_gift:['هدية اليوم',1,75],luck_spin:['حظ كبرياء',1,100],svip_support:['دعم SVIP',1,300],cp_event:['CP Challenge',1,250]};
  const d=definitions[req.params.key];if(!d)return res.status(404).json({error:'task_not_found'});
  const row=(await pool.query('SELECT * FROM user_tasks WHERE user_id=$1 AND task_key=$2',[req.user.id,req.params.key])).rows[0];
  if(!row || row.claimed || row.progress<d[1]) return res.status(409).json({error:'task_not_ready'});
  const claimed=(await pool.query('UPDATE user_tasks SET claimed=true,updated_at=now() WHERE id=$1 AND claimed=false RETURNING id',[row.id])).rows[0];if(!claimed)return res.status(409).json({error:'already_claimed'});await credit(req.user.id,d[2],`task:${req.params.key}`);res.json({ok:true,reward:d[2]});
});
app.post('/api/tasks/:key/progress',auth,async(req,res)=>res.status(403).json({error:'manual_progress_disabled'}));

app.post('/api/ratings',auth,async(req,res)=>{const rating=Number(req.body.rating);const comment=String(req.body.comment||'').slice(0,500);if(!Number.isInteger(rating)||rating<1||rating>5)return res.status(400).json({error:'rating_1_to_5'});const {rows}=await pool.query(`INSERT INTO app_ratings(user_id,rating,comment) VALUES($1,$2,$3) ON CONFLICT(user_id) DO UPDATE SET rating=EXCLUDED.rating,comment=EXCLUDED.comment,updated_at=now() RETURNING *`,[req.user.id,rating,comment||null]);await pool.query(`INSERT INTO user_tasks(user_id,task_key,progress,target) VALUES($1,'rate_app',1,1) ON CONFLICT(user_id,task_key) DO UPDATE SET progress=1,updated_at=now()`,[req.user.id]);res.json({rating:rows[0]});});
app.get('/api/ratings/summary',async(_,res)=>{const r=(await pool.query(`SELECT COALESCE(ROUND(AVG(rating)::numeric,2),0) average,COUNT(*)::int count FROM app_ratings`)).rows[0];res.json(r);});
app.get('/api/ratings/me',auth,async(req,res)=>{res.json({rating:(await pool.query('SELECT * FROM app_ratings WHERE user_id=$1',[req.user.id])).rows[0]||null});});

app.post('/api/reports',auth,async(req,res)=>{const {targetUserId,roomId,reason,details}=req.body;const {rows}=await pool.query('INSERT INTO reports(reporter_id,target_user_id,room_id,reason,details) VALUES($1,$2,$3,$4,$5) RETURNING id',[req.user.id,targetUserId||null,roomId||null,reason,details||null]);res.json({id:rows[0].id});});

app.get('/api/admin/overview',auth,admin,async(_,res)=>{
  const q=async(sql)=>Number((await pool.query(sql)).rows[0].count||0);
  const [users,rooms,reports,ratings,coins]=await Promise.all([q('SELECT count(*) FROM users'),q("SELECT count(*) FROM rooms WHERE status='live'"),q("SELECT count(*) FROM reports WHERE status='open'"),q('SELECT count(*) FROM app_ratings'),q('SELECT COALESCE(sum(coins),0)::bigint count FROM users')]);
  res.json({users,liveRooms:rooms,openReports:reports,ratings,totalCoins:coins,owner:req.user.username});
});
app.get('/api/admin/control-center',auth,admin,ownerOnly,async(_,res)=>{
  const q=async(sql)=> (await pool.query(sql)).rows[0];
  const [users,rooms,tx,coins,diamonds,vip,svip,refs,bag,giftTypes,cvEvents,games,ratings,reports,audit]=await Promise.all([
    q('SELECT count(*)::int count FROM users'),q("SELECT count(*)::int count FROM rooms WHERE status='live'"),q('SELECT count(*)::int count FROM gift_transactions'),
    q('SELECT COALESCE(sum(coins),0)::bigint value FROM users'),q('SELECT COALESCE(sum(diamonds),0)::bigint value FROM users'),
    q('SELECT count(*)::int count FROM users WHERE vip_level>0'),q('SELECT count(*)::int count FROM users WHERE svip_level>0'),
    q('SELECT COALESCE(sum(referral_count),0)::int count FROM users'),q('SELECT COALESCE(sum(quantity),0)::bigint value FROM user_bag'),
    q('SELECT count(*)::int count FROM gifts'),q('SELECT count(*)::int count FROM cp_events WHERE enabled=true'),q('SELECT count(*)::int count FROM games WHERE enabled=true'),q('SELECT count(*)::int count FROM app_ratings'),
    q("SELECT count(*)::int count FROM reports WHERE status='open'"),q('SELECT count(*)::int count FROM owner_audit_log')
  ]);
  res.json({users:users.count,liveRooms:rooms.count,giftTransactions:tx.count,totalCoins:coins.value,totalDiamonds:diamonds.value,vipUsers:vip.count,svipUsers:svip.count,totalReferrals:refs.count,bagItems:bag.value,giftTypes:giftTypes.count,activeCpEvents:cvEvents.count,games:games.count,ratings:ratings.count,openReports:reports.count,auditEntries:audit.count,storageMode:'local_uploads'});
});
app.get('/api/admin/tasks',auth,admin,async(_,res)=>res.json({tasks:(await pool.query(`SELECT task_key,COUNT(*) FILTER (WHERE claimed)::int claimed_count,COUNT(*)::int total_rows,MAX(progress)::int max_progress,MAX(target)::int target FROM user_tasks GROUP BY task_key ORDER BY task_key`)).rows}));
app.get('/api/admin/audit',auth,admin,ownerOnly,async(_,res)=>res.json({entries:(await pool.query(`SELECT a.*,u.username owner_username FROM owner_audit_log a LEFT JOIN users u ON u.id=a.owner_id ORDER BY a.created_at DESC LIMIT 100`)).rows}));
app.get('/api/admin/users',auth,admin,async(_,res)=>res.json({users:(await pool.query('SELECT id,username,display_name,level,coins,diamonds,vip_level,svip_level,attraction,staff_role,is_banned,is_admin,referral_count,created_at FROM users ORDER BY created_at DESC LIMIT 100')).rows}));
app.get('/api/admin/reports',auth,admin,async(_,res)=>res.json({reports:(await pool.query('SELECT * FROM reports ORDER BY created_at DESC LIMIT 100')).rows}));
app.patch('/api/admin/users/:id/ban',auth,admin,ownerOnly,async(req,res)=>{const banned=Boolean(req.body.banned);await pool.query('UPDATE users SET is_banned=$1 WHERE id=$2',[banned,req.params.id]);res.json({ok:true,banned});});

app.get('/api/admin/gifts',auth,admin,async(_,res)=>res.json({gifts:(await pool.query('SELECT * FROM gifts ORDER BY category,sort_order,price_coins')).rows}));
app.patch('/api/admin/gifts/:id',auth,admin,ownerOnly,async(req,res)=>{const fields=['price_coins','enabled','min_vip','min_svip','combo_max','luck_weight'];const sets=[];const vals=[];for(const f of fields){if(req.body[f]!==undefined){vals.push(req.body[f]);sets.push(`${f}=$${vals.length}`);}}if(!sets.length)return res.status(400).json({error:'no_changes'});vals.push(req.params.id);const row=(await pool.query(`UPDATE gifts SET ${sets.join(',')} WHERE id=$${vals.length} RETURNING *`,vals)).rows[0];res.json({gift:row});});
app.get('/api/admin/cp-events',auth,admin,async(_,res)=>res.json({events:(await pool.query('SELECT * FROM cp_events ORDER BY starts_at DESC NULLS LAST')).rows}));
app.post('/api/admin/cp-events',auth,admin,ownerOnly,async(req,res)=>{const {title,description,targetValue=50000,rewardCoins=5000,rewardXp=500}=req.body;const row=(await pool.query('INSERT INTO cp_events(title,description,target_value,reward_coins,reward_xp) VALUES($1,$2,$3,$4,$5) RETURNING *',[title,description,targetValue,rewardCoins,rewardXp])).rows[0];res.json({event:row});});
app.patch('/api/admin/users/:id/economy',auth,admin,ownerOnly,async(req,res)=>{const allowed=['coins','diamonds','vip_level','svip_level','charge_level','attraction','charm_level','level'];const sets=[];const vals=[];for(const f of allowed){if(req.body[f]!==undefined){const n=Number(req.body[f]);if(!Number.isFinite(n)||n<0||!Number.isInteger(n))return res.status(400).json({error:`invalid_${f}`});vals.push(n);sets.push(`${f}=$${vals.length}`);}}if(!sets.length)return res.status(400).json({error:'no_changes'});vals.push(req.params.id);const row=(await pool.query(`UPDATE users SET ${sets.join(',')} WHERE id=$${vals.length} RETURNING id,username,coins,diamonds,vip_level,svip_level,charge_level,attraction,charm_level,level`,vals)).rows[0];res.json({user:row});});
app.patch('/api/admin/reports/:id',auth,admin,ownerOnly,async(req,res)=>{const status=String(req.body.status||'resolved');if(!['open','reviewing','resolved','dismissed'].includes(status))return res.status(400).json({error:'invalid_status'});const row=(await pool.query('UPDATE reports SET status=$1 WHERE id=$2 RETURNING *',[status,req.params.id])).rows[0];res.json({report:row});});
app.get('/api/admin/rooms',auth,admin,async(_,res)=>{const rows=(await pool.query(`SELECT r.*,u.display_name owner_name,u.username owner_username,(SELECT count(*) FROM room_members m WHERE m.room_id=r.id)::int viewers,(SELECT count(*) FROM room_bans b WHERE b.room_id=r.id)::int banned_count FROM rooms r JOIN users u ON u.id=r.owner_id ORDER BY r.created_at DESC LIMIT 200`)).rows;res.json({rooms:rows});});
app.patch('/api/admin/rooms/:id',auth,admin,ownerOnly,async(req,res)=>{const allowed=['title','announcement','background_url','cover_url','is_locked','seat_locked','max_seats','status','music_url','music_title','music_is_playing'];const sets=[],vals=[];for(const f of allowed){if(req.body[f]!==undefined){let v=req.body[f];if(f==='max_seats')v=Math.min(30,Math.max(1,Number(v)||30));if(f==='status'&&!['live','ended','suspended'].includes(String(v)))return res.status(400).json({error:'invalid_status'});vals.push(v);sets.push(`${f}=$${vals.length}`);}}if(!sets.length)return res.status(400).json({error:'no_changes'});vals.push(req.params.id);const row=(await pool.query(`UPDATE rooms SET ${sets.join(',')} WHERE id=$${vals.length} RETURNING *`,vals)).rows[0];if(!row)return res.status(404).json({error:'room_not_found'});io.to(`room:${req.params.id}`).emit('room:settings',row);res.json({room:row});});
app.post('/api/admin/rooms/:id/kick',auth,admin,ownerOnly,async(req,res)=>{await pool.query('DELETE FROM room_members WHERE room_id=$1 AND user_id=$2',[req.params.id,String(req.body.userId||'')]);io.to(`room:${req.params.id}`).emit('room:kick',{userId:String(req.body.userId||'')});res.json({ok:true});});
app.post('/api/admin/rooms/:id/ban',auth,admin,ownerOnly,async(req,res)=>{const uid=String(req.body.userId||'');if(!uid)return res.status(400).json({error:'missing_user'});await pool.query('INSERT INTO room_bans(room_id,user_id,banned_by,reason) VALUES($1,$2,$3,$4) ON CONFLICT(room_id,user_id) DO UPDATE SET banned_by=EXCLUDED.banned_by,reason=EXCLUDED.reason,created_at=now()',[req.params.id,uid,req.user.id,String(req.body.reason||'admin')]);await pool.query('DELETE FROM room_members WHERE room_id=$1 AND user_id=$2',[req.params.id,uid]);io.to(`room:${req.params.id}`).emit('room:ban',{userId:uid});res.json({ok:true});});
app.get('/api/admin/owner-settings',auth,admin,async(_,res)=>res.json({settings:(await pool.query('SELECT key,value FROM owner_settings ORDER BY key')).rows}));
app.put('/api/admin/owner-settings/:key',auth,admin,ownerOnly,async(req,res)=>{const row=(await pool.query('INSERT INTO owner_settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value RETURNING *',[req.params.key,req.body.value||{}])).rows[0];res.json({setting:row});});
app.get('/api/admin/rooms/controls',auth,admin,async(_,res)=>{res.json({presets:['royal','galaxy','neon','velvet','cinema'],emotes:(await pool.query('SELECT * FROM emotes ORDER BY sort_order')).rows,rockets:(await pool.query('SELECT * FROM room_rockets ORDER BY created_at DESC LIMIT 100')).rows,pk:(await pool.query('SELECT * FROM pk_challenges ORDER BY started_at DESC NULLS LAST LIMIT 100')).rows});});
app.get('/api/admin/economy',auth,admin,async(_,res)=>{const [users,gifts,tx,svip,vip]=await Promise.all([pool.query('SELECT COALESCE(sum(coins),0)::bigint coins,COALESCE(sum(diamonds),0)::bigint diamonds FROM users'),pool.query('SELECT count(*)::int count FROM gifts WHERE enabled=true'),pool.query('SELECT COALESCE(sum(total_coins),0)::bigint total,count(*)::int count FROM gift_transactions'),pool.query('SELECT count(*)::int count FROM users WHERE svip_level>0'),pool.query('SELECT count(*)::int count FROM users WHERE vip_level>0')]);res.json({wallets:users.rows[0],gifts:gifts.rows[0].count,giftTransactions:tx.rows[0],svipUsers:svip.rows[0].count,vipUsers:vip.rows[0].count});});
app.post('/api/zego/token',auth,async(req,res)=>{
  try { const {roomId}=req.body; const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[roomId])).rows[0]; if(!room)return res.status(404).json({error:'room_not_found'}); const member=(await pool.query('SELECT seat_index FROM room_members WHERE room_id=$1 AND user_id=$2',[roomId,req.user.id])).rows[0]; const isHost=String(room.owner_id)===String(req.user.id); const canPublish=isHost||Boolean(member&&member.seat_index!==null); const payload=JSON.stringify({room_id:roomId||'',privilege:{1:1,2:canPublish?1:0},stream_id_list:[]}); const token=generateToken04(process.env.ZEGO_APP_ID,req.user.id,process.env.ZEGO_SERVER_SECRET,Number(process.env.ZEGO_TOKEN_TTL||3600),payload); res.json({token,appId:Number(process.env.ZEGO_APP_ID),userId:req.user.id,userName:req.user.display_name,isHost,canPublish,maxSeats:Math.min(MAX_SEATS,room.max_seats||MAX_SEATS),seatLocked:Boolean(room.seat_locked)}); } catch(e){res.status(500).json({error:e.message});}
});

io.use((socket,next)=>{try{const p=jwt.verify(socket.handshake.auth?.token||'',process.env.JWT_SECRET,{issuer:'kibriya-chat',audience:'kibriya-app'});socket.userId=p.sub;next();}catch{next(new Error('unauthorized'));}});
io.on('connection',socket=>{
  socket.on('room:join',async(roomId)=>{ try { const room=(await pool.query('SELECT id,is_locked,owner_id FROM rooms WHERE id=$1',[roomId])).rows[0]; if(!room)return; const member=(await pool.query('SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2',[roomId,socket.userId])).rows[0]; const banned=(await pool.query('SELECT 1 FROM room_bans WHERE room_id=$1 AND user_id=$2',[roomId,socket.userId])).rows[0]; if(banned || (!member && String(room.owner_id)!==String(socket.userId)))return; socket.join(`room:${roomId}`); } catch {} });
  socket.on('room:leave',roomId=>socket.leave(`room:${roomId}`));
  socket.on('room:typing',async(roomId)=>{ try { const member=(await pool.query('SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2',[roomId,socket.userId])).rows[0]; if(member) socket.to(`room:${roomId}`).emit('room:typing',{userId:socket.userId}); } catch {} });
});

httpServer.listen(Number(process.env.PORT||8080),()=>console.log(`Kibriya API listening on :${process.env.PORT||8080}`));

// ===== V8 social/room features =====
app.patch('/api/rooms/:id/settings',auth,async(req,res)=>{const room=(await pool.query('SELECT * FROM rooms WHERE id=$1',[req.params.id])).rows[0];if(!room||String(room.owner_id)!==String(req.user.id))return res.status(403).json({error:'owner_only'});const allowed=['title','announcement','background_url','cover_url','is_locked','seat_locked','max_seats'];const sets=[];const vals=[];for(const f of allowed){if(req.body[f]!==undefined){let v=req.body[f];if(f==='max_seats')v=Math.min(30,Math.max(1,Number(v)||30));vals.push(v);sets.push(`${f}=$${vals.length}`);}}if(!sets.length)return res.status(400).json({error:'no_changes'});vals.push(req.params.id);const row=(await pool.query(`UPDATE rooms SET ${sets.join(',')} WHERE id=$${vals.length} RETURNING *`,vals)).rows[0];io.to(`room:${req.params.id}`).emit('room:settings',row);res.json({room:row});});
app.get('/api/room/:roomId/stats',auth,async(req,res)=>{
  const row=(await pool.query(`SELECT rs.*, COALESCE(r.title,'') title FROM room_stats rs LEFT JOIN rooms r ON r.id=rs.room_id WHERE rs.room_id=$1`,[req.params.roomId])).rows[0] || {room_id:req.params.roomId,total_coins:0,total_gifts:0,total_diamonds:0,total_attraction:0};
  res.json(row);
});
app.get('/api/room/:roomId/emotes',auth,async(req,res)=>{
  const u=(await pool.query('SELECT vip_level,svip_level FROM users WHERE id=$1',[req.user.id])).rows[0];
  res.json({emotes:(await pool.query('SELECT * FROM emotes WHERE enabled=true AND min_vip<=$1 AND min_svip<=$2 ORDER BY sort_order',[u.vip_level||0,u.svip_level||0])).rows});
});
app.post('/api/room/:roomId/emotes',auth,async(req,res)=>{
  const e=(await pool.query('SELECT * FROM emotes WHERE id=$1 AND enabled=true',[req.body.emoteId])).rows[0]; if(!e)return res.status(404).json({error:'emote_not_found'});
  const u=(await pool.query('SELECT vip_level,svip_level FROM users WHERE id=$1',[req.user.id])).rows[0];
  if((u.vip_level||0)<e.min_vip || (u.svip_level||0)<e.min_svip)return res.status(403).json({error:'membership_required'});
  const ev=(await pool.query('INSERT INTO room_emote_events(room_id,user_id,emote_id) VALUES($1,$2,$3) RETURNING id,created_at',[req.params.roomId,req.user.id,e.id])).rows[0];
  io.to(`room:${req.params.roomId}`).emit('room:emote',{event:ev,userId:req.user.id,emote:e}); res.json({event:ev,emote:e});
});
app.get('/api/room/:roomId/backgrounds',auth,async(req,res)=>res.json({presets:['assets/backgrounds/royal.jpg','assets/backgrounds/galaxy.jpg','assets/backgrounds/neon.jpg','assets/backgrounds/velvet.jpg'],custom:(await pool.query('SELECT * FROM room_backgrounds WHERE room_id=$1 ORDER BY created_at DESC',[req.params.roomId])).rows}));
app.post('/api/room/:roomId/backgrounds',auth,async(req,res)=>{const room=(await pool.query('SELECT owner_id FROM rooms WHERE id=$1',[req.params.roomId])).rows[0];if(!room)return res.status(404).json({error:'room_not_found'});if(String(room.owner_id)!==String(req.user.id))return res.status(403).json({error:'owner_only'});const row=(await pool.query('INSERT INTO room_backgrounds(room_id,url,source,is_active) VALUES($1,$2,\'phone\',false) RETURNING *',[req.params.roomId,String(req.body.url)])).rows[0];res.json({background:row});});
app.post('/api/room/:roomId/lucky-bags',auth,async(req,res)=>{const member=(await pool.query('SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2',[req.params.roomId,req.user.id])).rows[0];if(!member)return res.status(403).json({error:'room_membership_required'});const coins=Math.max(1,Number(req.body.totalCoins)||0),limit=Math.max(1,Math.min(100,Number(req.body.recipientsLimit)||10));const client=await pool.connect();try{await client.query('BEGIN');const u=(await client.query('SELECT coins FROM users WHERE id=$1 FOR UPDATE',[req.user.id])).rows[0];if(Number(u.coins)<coins)throw new Error('insufficient_coins');await client.query('UPDATE users SET coins=coins-$1 WHERE id=$2',[coins,req.user.id]);const bag=(await client.query('INSERT INTO lucky_bags(room_id,sender_id,total_coins,remaining_coins,recipients_limit) VALUES($1,$2,$3,$3,$4) RETURNING *',[req.params.roomId,req.user.id,coins,limit])).rows[0];await client.query('COMMIT');io.to(`room:${req.params.roomId}`).emit('room:luckyBag',bag);res.json({bag});}catch(e){await client.query('ROLLBACK');res.status(400).json({error:e.message});}finally{client.release();}});
app.post('/api/room/:roomId/rockets',auth,async(req,res)=>{const member=(await pool.query('SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2',[req.params.roomId,req.user.id])).rows[0];if(!member)return res.status(403).json({error:'room_membership_required'});const target=Math.max(1,Number(req.body.targetCoins)||100000);const row=(await pool.query('INSERT INTO room_rockets(room_id,target_coins,rocket_count) VALUES($1,$2,3) RETURNING *',[req.params.roomId,target])).rows[0];res.json({rocket:row});});
app.post('/api/room/:roomId/pk',auth,async(req,res)=>{const memberA=(await pool.query('SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2',[req.params.roomId,req.user.id])).rows[0];const memberB=(await pool.query('SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2',[req.body.roomBId,req.user.id])).rows[0];if(!memberA||!memberB)return res.status(403).json({error:'room_membership_required'});const row=(await pool.query('INSERT INTO pk_challenges(room_a,room_b,target_coins,started_at,ends_at,status) VALUES($1,$2,$3,now(),now()+interval \'10 minutes\',\'live\') RETURNING *',[req.params.roomId,req.body.roomBId,Number(req.body.targetCoins)||100000])).rows[0];io.to(`room:${req.params.roomId}`).emit('room:pkStart',row);res.json({pk:row});});

app.post('/api/follows/:userId',auth,async(req,res)=>{if(String(req.user.id)===String(req.params.userId))return res.status(400).json({error:'self_follow'});await pool.query('INSERT INTO follows(follower_id,following_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.id,req.params.userId]);res.json({following:true});});
app.delete('/api/follows/:userId',auth,async(req,res)=>{await pool.query('DELETE FROM follows WHERE follower_id=$1 AND following_id=$2',[req.user.id,req.params.userId]);res.json({following:false});});
app.get('/api/follows/mutual/:userId',auth,async(req,res)=>{const r=(await pool.query(`SELECT EXISTS(SELECT 1 FROM follows WHERE follower_id=$1 AND following_id=$2) AND EXISTS(SELECT 1 FROM follows WHERE follower_id=$2 AND following_id=$1) mutual`,[req.user.id,req.params.userId])).rows[0];res.json(r);});
app.post('/api/messages',auth,async(req,res)=>{const other=String(req.body.receiverId);const mutual=(await pool.query(`SELECT EXISTS(SELECT 1 FROM follows WHERE follower_id=$1 AND following_id=$2) AND EXISTS(SELECT 1 FROM follows WHERE follower_id=$2 AND following_id=$1) mutual`,[req.user.id,other])).rows[0].mutual;if(!mutual)return res.status(403).json({error:'mutual_follow_required'});const row=(await pool.query('INSERT INTO messages(sender_id,receiver_id,kind,body,media_url,duration_ms) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',[req.user.id,other,req.body.kind||'text',req.body.body||null,req.body.mediaUrl||null,req.body.durationMs||null])).rows[0];res.json({message:row});});
app.get('/api/messages/:userId',auth,async(req,res)=>{const mutual=(await pool.query(`SELECT EXISTS(SELECT 1 FROM follows WHERE follower_id=$1 AND following_id=$2) AND EXISTS(SELECT 1 FROM follows WHERE follower_id=$2 AND following_id=$1) mutual`,[req.user.id,req.params.userId])).rows[0].mutual;if(!mutual)return res.status(403).json({error:'mutual_follow_required'});res.json({messages:(await pool.query('SELECT * FROM messages WHERE (sender_id=$1 AND receiver_id=$2) OR (sender_id=$2 AND receiver_id=$1) ORDER BY created_at ASC LIMIT 200',[req.user.id,req.params.userId])).rows});});
app.post('/api/families',auth,async(req,res)=>{const client=await pool.connect();try{await client.query('BEGIN');const f=(await client.query('INSERT INTO families(name,owner_id) VALUES($1,$2) RETURNING *',[String(req.body.name||'عائلة كبرياء'),req.user.id])).rows[0];await client.query('INSERT INTO family_members(family_id,user_id,role) VALUES($1,$2,\'owner\')',[f.id,req.user.id]);await client.query('COMMIT');res.json({family:f});}catch(e){await client.query('ROLLBACK');res.status(400).json({error:e.message});}finally{client.release();}});
app.post('/api/families/:id/join',auth,async(req,res)=>{const row=(await pool.query('INSERT INTO family_members(family_id,user_id) VALUES($1,$2) ON CONFLICT DO NOTHING RETURNING *',[req.params.id,req.user.id])).rows[0];res.json({member:row||null});});
app.get('/api/families/:id/messages',auth,async(req,res)=>{const member=(await pool.query('SELECT 1 FROM family_members WHERE family_id=$1 AND user_id=$2',[req.params.id,req.user.id])).rowCount;if(!member)return res.status(403).json({error:'family_membership_required'});res.json({messages:(await pool.query('SELECT * FROM family_messages WHERE family_id=$1 ORDER BY created_at ASC LIMIT 300',[req.params.id])).rows});});
app.post('/api/families/:id/messages',auth,async(req,res)=>{const member=(await pool.query('SELECT 1 FROM family_members WHERE family_id=$1 AND user_id=$2',[req.params.id,req.user.id])).rowCount;if(!member)return res.status(403).json({error:'family_membership_required'});const row=(await pool.query('INSERT INTO family_messages(family_id,sender_id,kind,body,media_url,duration_ms) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',[req.params.id,req.user.id,req.body.kind||'text',req.body.body||null,req.body.mediaUrl||null,req.body.durationMs||null])).rows[0];res.json({message:row});});
