# Kibriya Chat API

REST + Socket.IO + PostgreSQL + local persistent image storage.

## Local
1. `cp .env.example .env` and set a long `JWT_SECRET`.
2. Start PostgreSQL/Redis with `docker compose up -d postgres redis`.
3. Apply `sql/001_init.sql` and then the versioned migrations `002` through `009` to the `kibriya` database.
4. `npm install && npm start`.

## Docker
`docker compose up -d --build`

The `uploads` volume keeps uploaded images after container restarts. Later, if you want CDN/Object Storage, replace the upload adapter without changing the app API.

## WhatsApp OTP
Set `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_OTP_TEMPLATE`, and `WHATSAPP_OTP_LANGUAGE` for Meta WhatsApp Cloud API. The OTP is stored hashed, expires after 5 minutes, and is rate/attempt limited.

## Owner
Set `OWNER_USERNAME` before the owner creates the account. A registration whose username matches it is marked `is_admin=true` and can open the in-app Owner Panel.

## Security hardening

For production, read `SECURITY_HARDENING.md` first. Set `OWNER_USER_ID`, `JWT_SECRET`, `OTP_PEPPER`, `CORS_ORIGIN`, and `PUBLIC_BASE_URL`. Apply `sql/010_security_hardening.sql`. Public registration never creates admins; the owner account must be provisioned separately.

### V10.1 Cosmetics migration
بعد تحديث قاعدة البيانات شغّل:
```bash
psql "$DATABASE_URL" -f sql/010_cosmetics_stickers.sql
```
