import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../core/providers.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});
  @override ConsumerState<ProfileScreen> createState()=>_ProfileState();
}

class _ProfileState extends ConsumerState<ProfileScreen> {
  bool uploading=false;
  Map<String,dynamic>? cosmetics;

  @override void initState(){super.initState();_loadCosmetics();}
  Future<void> _loadCosmetics() async {try{final d=await ref.read(apiProvider).cosmetics();if(mounted)setState(()=>cosmetics=d);}catch(_){}}

  Future<void> _avatar() async {
    final x=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:85);if(x==null)return;
    setState(()=>uploading=true);
    try {final api=ref.read(apiProvider);final url=await api.uploadImage(x.path);await api.dio.patch('/api/me',data:{'avatarUrl':url});await ref.read(authProvider.notifier).restore();if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم حفظ الصورة بنجاح')));}
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر حفظ الصورة: $e')));}
    finally{if(mounted)setState(()=>uploading=false);}
  }

  Widget _frameAsset(String key){
    final items=List<dynamic>.from(cosmetics?['items']??[]);
    final found=items.where((e)=>'${e['item_key']}'==key).toList();
    if(found.isEmpty)return const SizedBox.shrink();
    final p='${found.first['asset_path']??''}';
    return p.endsWith('.svg')?SvgPicture.asset(p,fit:BoxFit.contain):Image.asset(p,fit:BoxFit.contain);
  }

  @override Widget build(BuildContext c){
    final u=ref.watch(authProvider).valueOrNull;
    final frameKey=cosmetics?['selected']?['profile_frame_key'];
    return Scaffold(
      appBar:AppBar(title:const Text('حسابي'),actions:[IconButton(onPressed:()=>ref.read(authProvider.notifier).logout(),icon:const Icon(Icons.logout))]),
      body:ListView(padding:const EdgeInsets.all(18),children:[
        Center(child:Stack(alignment:Alignment.center,children:[
          CircleAvatar(radius:52,backgroundImage:u?.avatarUrl!=null?NetworkImage(u!.avatarUrl!):null,child:u?.avatarUrl==null?const Icon(Icons.person,size:48):null),
          if(frameKey!=null)Positioned(width:142,height:142,child:_frameAsset('$frameKey')),
          Positioned(bottom:-2,right:-2,child:IconButton(onPressed:uploading?null:_avatar,style:IconButton.styleFrom(backgroundColor:Colors.amber),icon:uploading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.camera_alt,color:Colors.black))),
        ])),
        const SizedBox(height:12),
        Center(child:Text(u?.displayName??'',style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900))),
        Center(child:Text('@${u?.username??''}',style:TextStyle(color:Colors.white.withOpacity(.55)))),
        const SizedBox(height:22),
        Row(children:[_Stat('المستوى','${u?.level??1}'),_Stat('العملات','${u?.coins??0}'),_Stat('ألماس','${u?.diamonds??0}'),_Stat('VIP','${u?.vipLevel??0}'),_Stat('SVIP','${u?.svipLevel??0}')]),
        const SizedBox(height:24),
        Card(child:ListTile(leading:const Icon(Icons.auto_awesome),title:const Text('🎨 مظهر كبرياء'),subtitle:const Text('إطارات الرتب • دخولات VIP • إطارات الدردشة • الملصقات'),trailing:const Icon(Icons.chevron_left),onTap:()=>c.push('/cosmetics').then((_)=>_loadCosmetics()))),
        ...['المحفظة','الهدايا المستلمة','VIP والمستويات','SVIP والارتباط','مستوى الشحن والجاذبية','الحقيبة والهدايا','الأصدقاء والمتابعون','الوكالة','الشارات والإنجازات','الإعدادات والخصوصية','مركز الأمان'].map((x)=>Card(child:ListTile(title:Text(x),trailing:const Icon(Icons.chevron_left),onTap:(){}))),
        Card(child:ListTile(leading:const Icon(Icons.workspace_premium),title:const Text('👑 VIP / SVIP'),subtitle:const Text('شوف كل المستويات والامتيازات والتقدم'),trailing:const Icon(Icons.chevron_left),onTap:()=>c.push('/membership'))),
        Card(child:ListTile(leading:const Icon(Icons.trending_up),title:const Text('💰 مستوى الثروة'),subtitle:const Text('اعرف دعمت بكام وفاضلك كام للمستوى التالي'),trailing:const Icon(Icons.chevron_left),onTap:()=>c.push('/wealth'))),
        Card(child:ListTile(leading:const Icon(Icons.sports_esports),title:const Text('🎮 ألعاب كبرياء'),subtitle:const Text('5 ألعاب + محاولات مجانية يومية'),trailing:const Icon(Icons.chevron_left),onTap:()=>c.push('/games'))),
        Card(child:ListTile(leading:const Icon(Icons.card_giftcard),title:const Text('🎁 مركز الهدايا'),subtitle:const Text('أساسية • كومبو • حظ • SVIP • CP • مشاهير • دول'),trailing:const Icon(Icons.chevron_left),onTap:()=>c.push('/gifts'))),
        Card(child:ListTile(leading:const Icon(Icons.card_giftcard),title:const Text('دعوة صديق واربح'),subtitle:const Text('رابطك + أرباح الدعوات'),trailing:const Icon(Icons.chevron_left),onTap:()=>c.push('/referrals'))),
        Card(child:ListTile(leading:const Icon(Icons.task_alt),title:const Text('مهام كبرياء'),subtitle:const Text('مهمات يومية ومكافآت'),trailing:const Icon(Icons.chevron_left),onTap:()=>c.push('/tasks'))),
        Card(child:ListTile(leading:const Icon(Icons.star_rate),title:const Text('قيّم التطبيق'),trailing:const Icon(Icons.chevron_left),onTap:()=>c.push('/rating'))),
        if(u?.isAdmin==true)Card(child:ListTile(leading:const Icon(Icons.admin_panel_settings),title:const Text('لوحة المالك'),subtitle:const Text('إدارة المستخدمين والغرف والبلاغات'),trailing:const Icon(Icons.chevron_left),onTap:()=>c.push('/admin'))),
      ]),
    );
  }
}

class _Stat extends StatelessWidget{final String a,b;const _Stat(this.a,this.b);@override Widget build(BuildContext c)=>Expanded(child:Column(children:[Text(b,style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold)),Text(a,style:const TextStyle(fontSize:12,color:Colors.white54))]));}
