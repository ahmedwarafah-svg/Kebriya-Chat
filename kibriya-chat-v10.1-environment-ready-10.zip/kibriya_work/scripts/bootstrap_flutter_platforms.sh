#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/app"
command -v flutter >/dev/null 2>&1 || { echo "Flutter غير مثبت. ثبّت Flutter 3.29+ ثم أعد التشغيل."; exit 1; }
flutter create --platforms=android,ios .
flutter pub get
printf '\nتم تجهيز منصات Flutter وdependencies.\n'
